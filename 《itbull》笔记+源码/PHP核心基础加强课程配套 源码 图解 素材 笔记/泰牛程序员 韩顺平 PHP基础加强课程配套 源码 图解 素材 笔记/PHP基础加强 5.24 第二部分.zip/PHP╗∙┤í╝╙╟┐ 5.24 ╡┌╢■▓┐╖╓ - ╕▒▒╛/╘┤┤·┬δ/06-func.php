<?php
	header("content-type:text/html;charset=utf-8");
	//函数中要使用全局变量的时，使用global
	$a=12;
	function abc3(){
		//global $a, 表示我们希望使用全局区的$a变量
		//global $a; 等价于 $a = &$GLOBALS['a'];
		global $a; 
		$a += 45;
		echo 'abc3() $a = ' . $a;
	}
	abc3();
	echo '<br>' . $a;
