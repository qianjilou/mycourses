<?php
	header("content-type:text/html;charset=utf-8");
	//静态变量, 的特点是，只会被初始化一次

	$n1 = 10;
	function test(){
		static $n1 = 0;
		$n1++;
		echo $n1; 
	}
	test();
	test();
	test();