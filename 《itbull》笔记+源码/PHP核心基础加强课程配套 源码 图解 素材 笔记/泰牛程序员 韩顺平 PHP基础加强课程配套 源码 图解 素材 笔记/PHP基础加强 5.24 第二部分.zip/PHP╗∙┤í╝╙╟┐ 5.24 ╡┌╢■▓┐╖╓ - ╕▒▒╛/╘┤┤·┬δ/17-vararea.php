<?php
	header("content-type:text/html;charset=utf-8");
	
	//全局变量
	$a = 90;
	$hello = array('北京', '天津');
	
	function abc(){
		//局部变量
		$b = 10;
		//在函数内部使用全局变量
		global $a; //<===> $a = $GLOBALS['a'];
	}

	abc();

	echo 'hello';

	function abc2(){

		echo '<pre>';
		//在函数内部，我们不需要global 就可以使用 所谓超全局变量
		var_dump($GLOBALS);
		echo $GLOBALS['hello'][0];
	}

	abc2();