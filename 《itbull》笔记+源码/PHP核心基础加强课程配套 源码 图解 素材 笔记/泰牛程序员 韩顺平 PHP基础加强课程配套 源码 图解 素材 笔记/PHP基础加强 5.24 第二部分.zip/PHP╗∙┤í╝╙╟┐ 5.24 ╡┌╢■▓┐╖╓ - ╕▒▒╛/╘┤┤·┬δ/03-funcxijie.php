<?php
	header("content-type:text/html;charset=utf-8");
	//函数的参数类型说明

	function hello($val){
		
		var_dump($val);
	}

	hello(1);
	hello(1.3);
	hello("abc");


	function abc(){
	}
