<?php
	header("content-type:text/html;charset=utf-8");
	//数组的快速入门
	/*
	一个养鸡场有6只鸡，它们的体重分别是3kg,5kg,1kg,3.4kg,2kg,50kg 。请问这六只鸡的总体重是多少?平均体重是多少? 请你用现在掌握的技术编一个程序。array1.php

	*/
	//定义了一个数组，表示六只鸡的重量
	$hens = array(3, 5, 1, 3.4, 2, 50,3, 5, 1, 3.4, 2, 50,3, 5, 1, 3.4, 2, 50,3, 5, 1, 3.4, 2, 50,3, 5, 1, 3.4, 2, 503, 5, 1, 3.4, 2, 50,3, 5, 1, 3.4, 2, 50);
	//遍历数组
	$total_weight = 0;

	for($i = 0; $i < count($hens); $i++){
		
		$total_weight += $hens[$i];
	}
	echo '总的体重' . $total_weight . '<br>';
	echo '平均体重' . $total_weight/count($hens) . '<br>';

