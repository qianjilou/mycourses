<?php
	header("content-type:text/html;charset=utf-8");
	//定义数组的三种方式
	//注意，数组的下标是从0开始的.
	$arr[0]=1; // 0 => 1
	$arr[1]='泰牛程序员';
	$arr[2]=45;
	$arr[3]=90;
	$arr[4]=56.7;

	echo '<pre>';
	var_dump($arr);

	//第二种创建方式
	$arr_book = array('西游记', '红楼梦', '程序员宝典');
	echo '<pre>';
	var_dump($arr_book);

	//第三种创建方式
	$arr = array('no1' => '宋江', 'no2' => '小卢', 'no3' => '老吴');
	echo '<pre>';
	var_dump($arr);

	//细节说明
	//2.1 键(key) 可是是一个 整数(integer)【称索引数组】 或       字符串(string)【称关联数组】
	//2.2值(value) 可以是任意类型的值,比如
	$arr2 = array('person1'=>$arr, 'person2' => $arr_book);
	echo '<pre>';
	var_dump($arr2);



	//细节3
	/* PHP中也可以使用array来创建一个数组：
* 如果对给出的值没有指定键名，则取当前最大的整数索引值，而新的键名将是该值加一。如果指定的键名已经有了值，则该值会被覆盖。*/

	//$arr3 = array(5 => 43, 32, 56, "b" => 12);
	$arr3 = array(5 => 43, 32, 56, "b" => 12);
	echo '<pre>';
	var_dump($arr3);

	$arr4 = array(5 => 43, 32, 56, "b" => 12, 5 => 70);
	echo '<pre>';
	var_dump($arr4);



	/*
	使用 TRUE 作为键名将使 integer 1 成为键名。
使用 FALSE 作为键名将使 integer 0 成为键名。
使用 NULL 作为键名将等同于使用空字符串。
使用小数作为key将，自动截断小数部分:

	*/

	$arr5 = array(TRUE => 'hello1', FALSE => 'abc', NULL => 'tainiu', 56.7 => 'uuu' ,NULL => 'tainiu2');
	echo '<pre>';
	var_dump($arr5);
	echo $arr5[''];
