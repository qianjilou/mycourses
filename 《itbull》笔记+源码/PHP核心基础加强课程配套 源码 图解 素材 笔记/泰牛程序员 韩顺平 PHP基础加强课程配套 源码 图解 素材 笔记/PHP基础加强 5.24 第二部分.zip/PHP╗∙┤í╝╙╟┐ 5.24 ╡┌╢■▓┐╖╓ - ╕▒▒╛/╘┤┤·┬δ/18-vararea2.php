<?php
	header("content-type:text/html;charset=utf-8");
	//作用域的练习题
	$name = '泰牛';
	echo $GLOBALS['name'];

	unset($name);
	var_dump($GLOBALS['name']);

	$GLOBALS['age'] = 90; //<===> $age = 90;
	echo $age;
