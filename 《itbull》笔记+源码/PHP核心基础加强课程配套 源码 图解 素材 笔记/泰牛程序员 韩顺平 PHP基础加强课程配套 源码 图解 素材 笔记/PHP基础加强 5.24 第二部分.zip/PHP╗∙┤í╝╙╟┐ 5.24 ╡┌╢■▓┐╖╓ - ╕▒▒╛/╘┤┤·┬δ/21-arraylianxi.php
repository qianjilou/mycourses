<?php
	header("content-type:text/html;charset=utf-8");
	//php数组的自动增长特点
	/*
	请创建一个有100元素的数组，元素的值在
100~200之间（随机生成）

	*/

	$arr = array();
	for($i = 0; $i < 100; $i++){
		$arr[] = rand(100,200);
	}

	echo '<pre>';
	var_dump($arr);