<?php
	header("content-type:text/html;charset=utf-8");
	//函数传递参数的说明
/*	$a=213;
	function abc(&$b){
		$b=314;
	}	
	abc($a);	
	echo $a;*/

	$a = 213;
	function abc(&$b){
	
		//$b = null;
		unset($b);
	}

	abc($a);
	var_dump($a);


	




