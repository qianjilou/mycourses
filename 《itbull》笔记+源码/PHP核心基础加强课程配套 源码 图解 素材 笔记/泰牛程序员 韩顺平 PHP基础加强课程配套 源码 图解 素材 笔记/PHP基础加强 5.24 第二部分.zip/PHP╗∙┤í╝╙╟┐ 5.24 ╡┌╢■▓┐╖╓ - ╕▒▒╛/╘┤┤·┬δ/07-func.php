<?php
	header("content-type:text/html;charset=utf-8");
	
	function abc4(){
		//使用函数外面的$a,如果没有,则创建一个全局的$a变量
		global $a;
		$a = 100;
	}

	abc4();
	echo $a;