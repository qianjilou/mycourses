<?php
	header("content-type:text/html;charset=utf-8");
	//b.php
	echo '<br> main body start';
	
	$val = require 'a.php';

	var_dump($val);
	//a.文件
	echo '<br> main body end';