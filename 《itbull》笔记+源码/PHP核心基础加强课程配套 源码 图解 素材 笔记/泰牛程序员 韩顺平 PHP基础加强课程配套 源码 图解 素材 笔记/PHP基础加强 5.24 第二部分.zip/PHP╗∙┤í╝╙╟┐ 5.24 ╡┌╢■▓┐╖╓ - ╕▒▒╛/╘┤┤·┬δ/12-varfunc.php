<?php
	header("content-type:text/html;charset=utf-8");
	//可变函数

	function abc($n1, $n2){
		return $n1 + $n2;
	}

	echo abc(10, 90);

	$func_name = 'abc';

	echo '<br>' . $func_name(90, 90);
