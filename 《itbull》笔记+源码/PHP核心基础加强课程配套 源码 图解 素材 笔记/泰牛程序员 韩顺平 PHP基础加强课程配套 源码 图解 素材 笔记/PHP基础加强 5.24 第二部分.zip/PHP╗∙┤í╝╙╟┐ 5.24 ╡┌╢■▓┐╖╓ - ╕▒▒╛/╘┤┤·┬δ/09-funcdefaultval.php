<?php
	header("content-type:text/html;charset=utf-8");
	//函数的默认值说明
	// $a 的默认值为 2
	function abc($b,$a=2)
	{
		$res=$a+$b;
		return $res;
	}
	
	$e=70;
	
	echo abc($e).' || ' . abc($e,90);
