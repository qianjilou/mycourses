<?php
	header("content-type:text/html;charset=utf-8");
	
	echo '<br>hello, a.php';

	$db_config = array(
		'host' => 'localhost',
		'username' => 'root',
		'password' => 'root'
	);
	

	return $db_config;
	//当这里遇到return ,下面这句话不会执行
	echo '<br> yyy hello!';