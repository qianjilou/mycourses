<?php
	header("content-type:text/html;charset=utf-8");
	//递归
//	function abc($n){
//		
//		if($n > 2){
//			abc(--$n);
//		}
//
//		echo '$n = ' . $n;
//	}
//	//输出内容..
//	abc(4);

	/*
	1.请使用递归的方式求出斐波那契数
1,1,2,3,5,8,13...
给你一个整数n，求出它的值是多
$n = 6 ==> 8
$n = 7 ==> 13

	*/
	function getVal($n){

		//验证数据的正确

		if($n == 1 || $n == 2){
			return 1;
		}else{
			return getVal($n-1) + getVal($n-2);
		}
	}
	$res = getVal(3);
	echo 'res = ' . $res;
	
	/*
	f(1)=3;
f(n) = 2*f(n-1)+1;
请使用递归的思想编程，求出 f(n)的值
	*/

	function f($n){
		if($n == 1){
			return 3;
		}else{
			return 2*f($n-1)+1;
		}
	}

	echo '<br>' . f(10);

