<?php
	header("content-type:text/html;charset=utf-8");
	//匿名函数
	$fun1 = function ($n1, $n2){
		return $n1 + $n2;
	};
	//调用匿名函数
	echo $fun1(90,10);

