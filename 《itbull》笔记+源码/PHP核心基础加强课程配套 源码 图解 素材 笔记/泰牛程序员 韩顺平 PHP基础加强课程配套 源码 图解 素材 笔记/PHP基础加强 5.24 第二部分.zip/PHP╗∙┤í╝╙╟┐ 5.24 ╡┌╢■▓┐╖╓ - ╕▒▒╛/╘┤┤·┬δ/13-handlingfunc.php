<?php
	header("content-type:text/html;charset=utf-8");
	
	//编写一个函数，传入的参数个数不确定，请求出其和

	
//	function getSum(){
//		$val1 = func_num_args();
//		echo $val1;
//		//func_get_args 可以获取到所有参数的值,并且是数组
//		$val2 = func_get_args();
//		echo '<hr>';
//		echo '<pre>';
//		print_r($val2);
//		//func_get_arg(数字)， 可以返回到你指定的那个参数
//		echo '<hr>';
//		echo func_get_arg(3);
//
//
//	}

	//编写一个函数，传入的参数个数不确定，请求出其和
	function getSum(){
		$arr = func_get_args();
		$sum = 0;
		foreach($arr as $val){
			$sum += $val;
		}
		return $sum;
	}

	//getSum(1, 90, 89, 'hello', array(10, 20, 30));

	//编写一个函数，传入的参数个数不确定，请求出其和
	getSum(4, 9, 90);
	getSum(56, -6, -9, -190);




