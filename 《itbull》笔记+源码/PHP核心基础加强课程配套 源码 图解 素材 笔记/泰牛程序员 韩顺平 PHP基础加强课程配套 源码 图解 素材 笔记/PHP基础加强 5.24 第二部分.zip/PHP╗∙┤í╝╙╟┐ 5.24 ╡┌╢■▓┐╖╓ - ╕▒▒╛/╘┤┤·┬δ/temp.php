<?php
	header("content-type:text/html;charset=utf-8");
	
	//测试