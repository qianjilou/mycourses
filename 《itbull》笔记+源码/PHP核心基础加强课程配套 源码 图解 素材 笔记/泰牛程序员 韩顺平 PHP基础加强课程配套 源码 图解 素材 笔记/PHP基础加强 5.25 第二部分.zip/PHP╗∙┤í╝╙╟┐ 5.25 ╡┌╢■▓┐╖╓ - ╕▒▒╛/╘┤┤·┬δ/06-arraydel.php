<?php
	header("content-type:text/html;charset=utf-8");
	//删除数组的元素或整个数组

	$arr = array(10, 90, 100, -2);

	//删除 100这个值
	unset($arr[2]);

	echo '<pre>';
	var_dump($arr);

	//如果希望删除整个数组

	$arr2 = &$arr;

	unset($arr);

	var_dump($arr);
	echo '<hr>';
	var_dump($arr2);
