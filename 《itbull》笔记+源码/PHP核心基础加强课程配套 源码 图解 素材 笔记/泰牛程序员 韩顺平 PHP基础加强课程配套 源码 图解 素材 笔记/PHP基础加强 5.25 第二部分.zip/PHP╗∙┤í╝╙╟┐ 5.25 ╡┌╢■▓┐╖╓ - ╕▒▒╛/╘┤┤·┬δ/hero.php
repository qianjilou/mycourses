<?php
	header("content-type:text/html;charset=utf-8");
	
	//我先定义二维数组
	$person1 = array('xm' => '宋江', 'xb' => '男', 'wh' => '及时雨');
	$person2 = array('xm' => '宋江2', 'xb' => '男2', 'wh' => '及时雨2');
	$person3 = array('xm' => '宋江3', 'xb' => '男3', 'wh' => '及时雨3');

	$persons_list = array($person1, $person2, $person3);

	require 'herotemp.html';