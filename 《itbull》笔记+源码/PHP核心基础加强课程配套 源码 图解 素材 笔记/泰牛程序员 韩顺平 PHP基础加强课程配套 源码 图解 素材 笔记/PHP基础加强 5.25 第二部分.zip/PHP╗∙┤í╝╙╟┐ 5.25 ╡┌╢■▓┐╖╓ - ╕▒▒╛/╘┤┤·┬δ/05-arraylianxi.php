<?php
	header("content-type:text/html;charset=utf-8");
	//数组练习

	$arr = array(90, -2, 9);

	function mySort($n1, $n2){
		
		if($n1 == $n2){
			return 0;
		}else {
			return $n1 > $n2 ? -1:1;
		}
	}

	usort($arr, 'mySort');
	echo '<pre>';
	var_dump($arr);