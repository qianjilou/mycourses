<?php
	header("content-type:text/html;charset=utf-8");
	//顺序查找
	$arr = array(0, -1, 90, 23, 567, 567);

	function search(&$arr, $find_val){
		
	/*	foreach($arr as $key => $val){
			
			if($val == $find_val){
				echo '找到了 下标=' .  $key;
				return;
			}
		}

		echo "对不起，找到不该数据"; */

		//还有一种写法
		$arr_size = count($arr);
		$flag = 0;
		for($i = 0; $i < $arr_size; $i++){
			//判断是不是要查找的数
			if($arr[$i] == $find_val){
				$flag = 1;
				echo '<br> 找到一个了下标是 ' . $i; 
			}
		}

		if($flag == 0){
			
			echo "对不起，找到不该数据";
		}


	}
	
	search($arr, 567);

