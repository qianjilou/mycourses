<?php
	header("content-type:text/html;charset=utf-8");
	//冒泡排序
	
	set_time_limit(0);
	//$arr = array(10, 7, 1, -1, 0, -100, 78, 12345, 90);
	//$arr = array(1, 56, 90, 120, 890, 9000);
	$arr = range(1, 10000);

	
	
	//做一个优化处理，如果的数组已经是一个从小到大的顺序，我们就不需要在反复的比较了.
	

	function bubble(&$arr){
	
		$flag = 0;
		//先确定数组的大小
		$arr_size = count($arr);
		//确定大循环次数
		for($i = 0; $i < $arr_size - 1; $i++){	
			//echo '<br>循环的次数' . ($i+1);
			for($j = 0; $j < $arr_size - 1 - $i; $j++){
				//echo '<br> 第' . ($i+1) . '大循环中的 小循环的次数' . ($j+1);
				//让前面的数和后面的数，进行比较，如果前面的数比后面的数大，则交换数据
				if($arr[$j] > $arr[$j + 1]){
					//交换, 定义一个中间变量
					$temp = $arr[$j];
					$arr[$j] = $arr[$j + 1];
					$arr[$j + 1] = $temp;
					$flag = 1;
				}
			}
			
			
			if($flag == 0){
				//如果 $flag == 0, 说明数组没有进行一次交换，则该数组已经是一个从小到大顺序, 因此结束排序
				break ;
			}else{
				//如果 $flag == 1, 说明数组进行一次交换，则该数组还不是一个从小到大顺序, 因此重新设置为 0
				$flag = 0;
			}

		}
	}


	//排序冒泡
	//在排序前，打印时间
	date_default_timezone_set('PRC');
	echo '<br>' . date('H:i:s');
	bubble($arr);
	echo '<br>' . date('H:i:s');
	echo '<pre>';
	print_r($arr);