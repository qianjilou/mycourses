<?php
	header("content-type:text/html;charset=utf-8");
	//二进制和 位运算

	//~2=?      
	//2&3=? 
	//2|3=?

	echo ~2;
	echo '<br>';
	echo 2&3;
	echo '<br>';
	echo 2|3;
	
	// 这个相当于/2/2
	echo '<br>';
	echo 1>>2;

	echo '<br> ' . (1<<2);