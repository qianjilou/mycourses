<?php
	header("content-type:text/html;charset=utf-8");
	//选择排序法
	/*
	第一次从R[0]~R[n-1]中选取最小值，与R[0]交换，第二次从R[1]~R[n-1]中选取最小值，与R[1]交换，第三次从R[2]~R[n-1]中选取最小值，交换，依次类推
	*/

	$arr = array(10, 7, 1, -1, 90, 345, 89.45);
	function selectSort(&$arr){
		//获取数组大小
		$arr_size = count($arr);
		//大循环的次数
		for($i = 0; $i < $arr_size - 1; $i++){		
			//假定 $arr[$i] 就是最小值
			$min_val = $arr[$i];
			//把最小值下标记录
			$min_val_index = $i;

			//开始循环比较，找到真正的最小值，然后交换
			for($j = $i + 1; $j < $arr_size; $j++){			
				//判断
				if($min_val > $arr[$j]){
					//重新设置最小值和下标
					$min_val = $arr[$j];
					$min_val_index = $j;
				}
			}
			if($min_val_index != $i){
				//最后再交换
				$arr[$min_val_index] =  $arr[$i];
				$arr[$i] = $min_val;
			}
		}
	}

	
	selectSort($arr);
	echo '<pre>';
	print_r($arr);

	//从大到小排序
	function selectSort2(&$arr){
		//获取数组大小
		$arr_size = count($arr);
		//大循环的次数
		for($i = 0; $i < $arr_size - 1; $i++){		
			//假定 $arr[$i] 就是最大值
			$max_val = $arr[$i];
			//把最小值下标记录
			$max_val_index = $i;

			//开始循环比较，找到真正的最大值，然后交换
			for($j = $i + 1; $j < $arr_size; $j++){			
				//判断
				if($max_val < $arr[$j]){
					//重新设置最大值和下标
					$max_val = $arr[$j];
					$max_val_index = $j;
				}
			}
			if($max_val_index != $i){
				//最后再交换
				$arr[$max_val_index] =  $arr[$i];
				$arr[$i] = $max_val;
			}
		}
	}

	$cows = array(10,34,19, 100, 80);
	selectSort2($cows);
	echo '<hr>';
	print_r($cows);