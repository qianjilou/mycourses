<?php
	header("content-type:text/html;charset=utf-8");
	//关于数组的函数

	$arr = array(10, 90, 100);

	echo '<pre>';
	var_dump($arr);
	print_r($arr);


	//数组排序, 字符串数组,
	//当使用sort对字符串数组排序时，先比较第一个字母的编码大小，把小的排前面，如果第一个字母相同，则比较第二个字母，依次类推
	$arr = array('apple', 'orange', 'apu', 'banana');
	sort($arr);
	echo '<pre>';
	var_dump($arr);
	
	echo '<hr>';

	//数组排序, 是数值数组，则按照数值从小到大排序
	$arr = array(10, -10, 45, 1);
	sort($arr);
	echo '<pre>';
	var_dump($arr);

	//看需求, $arr = array('apple', 'orange', 'apu', 'banana');
	//需要安，每个元素的字符串的长度，从小到大
	//在第一个参数小于，等于或大于第二个参数时，该比较函数必须相应地返回一个小于，等于或大于 0 的整数。 

	//我自己定义一个函数，该函数判断的标准我们自己写
	function mySort($str1, $str2){
		
		if(strlen($str1) == strlen($str2)){
			return 0;
		}else{
			return strlen($str1) < strlen($str2) ? 1 : -1;
		}
	}
	$arr = array('apple', 'orange', 'apu', 'banana', 'z');
	usort($arr, 'mySort');

	echo '<br> 排序后的数组';
	print_r($arr);


	//array_merge() array_reverse() array_search() array_pop() array_push()



	$arr1 = array(1, 40);
	$arr2 = array(90, 30);
	$arr3 = array_merge($arr1, $arr2, $arr1);
	echo '<pre>';
	print_r($arr3);


	//细节1 如果数组包含数字键名，后面的值将不会覆盖原来的值，而是附加到后面。
	//细节2 如果输入的数组中有相同的字符串键名，则该键名后面的值将覆盖前一个值
	
	$arr1 = array('no1' => '白骨精', 'no2' => '蜘蛛精');
	$arr2 = array('no3' => '狐狸精', 'no1' => '蝎子精');

	$arr3 = array_merge($arr1, $arr2);
	print_r($arr3);

	//array_reverse
	$arr = array('apple', 'orange', 'apu', 'banana', 'z');
	$arrnew = array_reverse($arr);
	print_r($arrnew);


	//array_search()
	$arr = array('apple', 'orange', 'apu', 'banana', 'z');
	//查找看看有没有  'z'

	$key_index = array_search('z', $arr);
	echo '值为' . $arr[$key_index];


	
	//array_pop (出栈) 将数组最后一个单元弹出（出栈）
	//array_push(入栈) 将一个或多个单元压入数组的末尾

	$val = array_pop($arr);

	echo '<br> val = ' . $val;
	//当我们pop后，数组本身也变化
	var_dump($arr);

	
	$arr = array('apple', 'orange', 'apu', 'banana', 'z');
	array_push($arr, '孙悟空', array('hello', 'world'));
	var_dump($arr);









