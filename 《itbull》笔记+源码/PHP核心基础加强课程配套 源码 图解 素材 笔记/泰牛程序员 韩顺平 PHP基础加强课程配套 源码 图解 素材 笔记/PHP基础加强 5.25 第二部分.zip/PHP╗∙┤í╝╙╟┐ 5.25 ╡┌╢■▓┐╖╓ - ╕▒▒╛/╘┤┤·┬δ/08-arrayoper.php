<?php
	header("content-type:text/html;charset=utf-8");
	//数组的运算符

	$arr1 = array(1, 9);
	$arr2 = array(10, 0, 'no1'=>'hello');
	//  + 的特点是， 不会覆盖已经有的键
	$arr3 = $arr1 + $arr2;

	echo '<pre>';
	var_dump($arr3);


	$arr4 = array(1, 90);
	$arr5 = array(1, 90);

	if($arr4 == $arr5){
		echo '<br> $arr4 == $arr5';
	}

	if($arr4 === $arr5){
		echo '<br> $arr4 === $arr5';
	}

	
	
	echo '<hr>';
	$arr4 = array('no1'=>1, 90);
	$arr5 = array('no1'=>'1', 90);

	//如果 $a 和 $b 具有相同的键／值对则为 TRUE。当我们的值有字符串，在进行比较是，会转成数字比较
	if($arr4 == $arr5){
		echo '<br> $arr4 == $arr5';
	}

	//如果 $a 和 $b 具有相同的键／值对并且顺序和类型都相同则为 TRUE
	if($arr4 === $arr5){
		echo '<br> $arr4 === $arr5';
	}

	//这个!=和 == 的逻辑相反

	if($arr4 != $arr5){
		echo '<br> $arr4 != $arr5';
	}
	//这个 !== 指的是如果键-值不等，或者类型不等，就成立
	if($arr4 !== $arr5){
		echo '<br> $arr4 !== $arr5';
	}


