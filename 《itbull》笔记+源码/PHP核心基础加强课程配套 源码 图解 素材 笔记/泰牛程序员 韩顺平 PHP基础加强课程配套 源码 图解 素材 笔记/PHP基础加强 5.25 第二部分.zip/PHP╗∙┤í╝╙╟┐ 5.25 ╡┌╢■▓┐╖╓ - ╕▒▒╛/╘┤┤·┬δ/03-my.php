<?php
	header("content-type:text/html;charset=utf-8");
	//my.php
	//查询数据库，获取到你的导航栏目, 我先使用一个数组来模拟
	$nav_list = array('首页', '泰牛程序员', '每学网', '关于我们');

	//引入模板
	require 'mytemp.html';
