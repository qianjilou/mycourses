<?php
	header("content-type:text/html;charset=utf-8");
	
	//数组的遍历

	$colors = array('red', 'blue', 'green', 'yellow');

	//遍历方式 for
	for($i = 0; $i < count($colors); $i++){
		echo '<br>' . $colors[$i];
	}
	//遍历方式2  foreach, 是我们推荐使用方法

	foreach($colors as $key => $val){

		echo '<br>' . $key . ' ' . $val;
	}

	//遍历方式3  foreach, 是我们推荐使用方法

	foreach($colors as $val){
		echo '<br>' . $val;
	}


