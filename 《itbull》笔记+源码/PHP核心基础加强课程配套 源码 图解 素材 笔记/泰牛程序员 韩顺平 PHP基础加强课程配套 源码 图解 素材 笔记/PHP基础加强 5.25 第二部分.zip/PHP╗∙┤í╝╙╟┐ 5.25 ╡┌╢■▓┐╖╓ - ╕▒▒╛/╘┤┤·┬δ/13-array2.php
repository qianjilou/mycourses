<?php
	header("content-type:text/html;charset=utf-8");
	//二维数组的变量

	$arr = array(array(1, 90), array(100, 120, 90), array(100, 120, 'hello'), '泰牛');

	//遍历的方式, 使用for循环来实现遍历
	
	$arr1_size = count($arr);
	for($i = 0; $i < $arr1_size; $i++){
		
		if(is_array($arr[$i])){
			$arr2_size = count($arr[$i]);
			for($j = 0;$j < $arr2_size ; $j++){
				
				echo $arr[$i][$j] . ' '; 
			}
		}else{
			echo $arr[$i] . ' '; 
		}

		echo '<br>';

	}

	//使用foreach来遍历
	echo '<hr>';
	foreach($arr as $val){
		
		if(is_array($val)){
			foreach($val as $v){
				echo $v . ' ';
			}
		}else {
			echo $val . ' ';
		}
		echo '<br>';
	}


