<?php
	header("content-type:text/html;charset=utf-8");
	
	//二分查找
	/*
	思想: 
	1. 找到数组中间这个数，和你的查找的数进行比较
	1.1   相等， 找到
	1.2  中间这个数 >  你的查找的数(4),  你应该在左边继续查找
	1.3. 中间这个数 <  你的查找的数(4),  你应该在右边继续查找
	2. 上面的逻辑反复执行(递归掉用)

	*/

	/**
		@author: 顺平
		@parameter: $left_index 数组左边下标
		@parameter: $right_index 数组右边下标
		@parameter: $arr , 表示数组
		@parameter: $find_val 查找的值

	*/

	function binarySerach($left_index, $right_index, $arr, $find_val){
		
		//如果我们发现  $left_index > $right_index 就肯定找不到

		if($left_index > $right_index){
			echo '找不到数据';
			return;
		}
		//找到数组中间这个数，和你的查找的数进行比较
		//找到中间的下标
		$middle_index = round(($left_index + $right_index) / 2);
		
		if($arr[$middle_index] == $find_val){
			echo '恭喜查找到' .$middle_index;
			return;
		}else if( $arr[$middle_index] > $find_val ){

			binarySerach($left_index , $middle_index -1, $arr , $find_val);

		}else if( $arr[$middle_index] < $find_val ){

			binarySerach($middle_index + 1 , $right_index , $arr , $find_val);

		}

	}

	$arr = array(1, 2, 3, 4, 10, 80 , 90 , 100, 200);

	binarySerach(0, count($arr) - 1, $arr, 9);