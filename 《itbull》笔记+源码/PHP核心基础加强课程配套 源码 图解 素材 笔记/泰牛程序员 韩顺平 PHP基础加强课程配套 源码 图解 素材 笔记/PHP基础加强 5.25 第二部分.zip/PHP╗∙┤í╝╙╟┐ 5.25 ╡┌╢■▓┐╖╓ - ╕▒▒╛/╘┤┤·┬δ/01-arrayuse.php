<?php
	header("content-type:text/html;charset=utf-8");
	//数组的使用(引用)

	$arr = array(10, 30, 'no1' => '你好!');

	echo $arr[0] .  $arr['no1'];

	//细节1, 如果我们使用了一个不存在的键, 提示一个undefined offset
	echo $arr[9];
	echo 'ok';

	//细节2, 数组的下标值的增长是当前值+1
	$a=array(2,3);
	$a[9]=56;
	$a[]=100;
	echo '<pre>';
	var_dump($a);
