<?php
	header("content-type:text/html;charset=utf-8");
	//这里我们接收一下数据

	echo '<pre>';
	var_dump($_POST);