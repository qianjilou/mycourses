<?php
	header("content-type:text/html;charset=utf-8");
	//error.php页面

	echo '小子，想盗链!';