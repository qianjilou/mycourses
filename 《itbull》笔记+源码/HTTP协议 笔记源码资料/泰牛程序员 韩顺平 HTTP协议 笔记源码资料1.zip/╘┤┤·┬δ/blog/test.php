<?php
	header("content-type:text/html;charset=utf-8");
	//获取http请求的消息头

	echo '<pre>';
	var_dump($_SERVER);