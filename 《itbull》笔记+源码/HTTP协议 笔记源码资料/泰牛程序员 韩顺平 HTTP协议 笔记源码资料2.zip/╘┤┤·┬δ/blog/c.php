<?php
	//这里header 就是消息头出现 Content-Type: text/html; charset=UTF-8 
	header("content-type:text/html;charset=utf-8");
	
	//消息头中出现location
//	header('Location: abc.html');
//	header('Location: http://www.baidu.com/');

	//last-modified

	echo '<img src="Jellyfish.jpg" width="400px" >';
