<?php
	header("content-type:text/html;charset=utf-8");
	
	
	echo intval('123.89');