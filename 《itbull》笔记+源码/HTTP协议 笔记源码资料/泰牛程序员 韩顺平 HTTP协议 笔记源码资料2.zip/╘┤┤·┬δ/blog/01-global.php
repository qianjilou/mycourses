<?php
	header("content-type:text/html;charset=utf-8");
	
	echo '<pre>';
	var_dump($_GET);
	

	function abc(){
		//这里我们不要声明直接使用
		var_dump($_SERVER);
	}

	abc();