<?php
	header("content-type:text/html;charset=utf-8");
	//a.php 来演示常用的响应状态码的情形

	//当我们请求没有问题时，这就会返回200状态码
	echo '<h1>hello,ABC</h1>';

	//演示302状态码
	//header('Location: abc.html');
	//这里演示304状态码
	echo "<img src='Desert.jpg' width='400px'>";

