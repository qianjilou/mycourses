<?php
	header("content-type:text/html;charset=utf-8");
	//showPerson.php 显示用户信息的页面

	//先获取到 refer值
	$refer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';

	//strpos($refer, 'http://www.hsp.com') ===0 说明 $referer 必须有 http://www.hsp.com,而且必须开头
	if($refer != '' && strpos($refer, 'http://www.hsp.com') ===0 ){
		echo '<hr>';
		echo '<br>小丽的年龄 : 18岁!';
		echo '<br>小丽的身高 : 180cm!';
		echo '<br>小丽的颜值 : 99分!';
	}else{
		//坏人
		header('Location: err.php');
	}

