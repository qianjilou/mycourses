<?php
	header("content-type:text/html;charset=utf-8");
	//b.php 页面，使用$_REQUEST方式来接收数据

	echo '<pre>';
	var_dump($_REQUEST);