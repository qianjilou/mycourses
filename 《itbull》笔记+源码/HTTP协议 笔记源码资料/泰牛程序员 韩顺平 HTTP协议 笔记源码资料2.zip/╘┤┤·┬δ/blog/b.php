<?php
	header("content-type:text/html;charset=gbk");

	echo 'yyy';
