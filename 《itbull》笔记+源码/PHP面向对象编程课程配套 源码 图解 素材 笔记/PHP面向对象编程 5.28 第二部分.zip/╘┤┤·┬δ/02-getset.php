<?php
	header("content-type:text/html;charset=utf-8");
	//这里我们讲解一把 __get 和 __set使用

	class Monkey{
		
		public $name;
		protected $food;

		function __construct($name, $food){
			
			$this->name = $name;
			$this->food = $food;
		}

		//写一个函数, 输出信息
		function sayHello(){
			echo '<br> 我是 ' . $this->name . ' 喜欢吃 ' . $this->food;
		}

		//魔术方法
		//__get , 读取不可访问属性的值(比如：private/protected/不存在)时，__get() 会被调用
		function __get($pro_name){
			//echo '<br> $pro_name' . $pro_name;
			echo '<br> __get';
			//先判断，该属性是否存在
			if(isset($this->$pro_name)){
				return $this->$pro_name;
			}else{
				return '<br> 属性不存在';
			}
		}
	
		//魔术方法 在给不可访问属性赋值(比如：private/protected/不存在)时，__set() 会被调用
		function __set($pro_name, $val){
			//echo '__set' . $pro_name . ' val=' . $val;
			//如果属性存在 ，就更新
			if(isset($this->$pro_name)){
				
				$this->$pro_name = $val;
			}else{
				echo '<br> 属性不存在';
			}
		}



	}

	$monkey = new Monkey('金丝猴', '桃子');

	$monkey->sayHello();

	echo '<br> 猴子喜欢吃' . $monkey->food;

	$monkey->food = '小孩';
	echo '<hr>';
	$monkey->sayHello();

	$monkey->sex = '女生';
	