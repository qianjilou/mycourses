<?php
	header("content-type:text/html;charset=utf-8");
	//Dog.class.php

	class Dog{
		
		public function cry(){
			echo '小狗汪汪叫...';
		}
	}