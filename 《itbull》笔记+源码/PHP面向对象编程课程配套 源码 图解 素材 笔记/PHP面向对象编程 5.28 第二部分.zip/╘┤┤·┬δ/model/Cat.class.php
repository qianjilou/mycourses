<?php
	header("content-type:text/html;charset=utf-8");
	//Cat.class.php
	class Cat{
		
		public function cry(){
			echo '小猫喵喵叫...';
		}
	}