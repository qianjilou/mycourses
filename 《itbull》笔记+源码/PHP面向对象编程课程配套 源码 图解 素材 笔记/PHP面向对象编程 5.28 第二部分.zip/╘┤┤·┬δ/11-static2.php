<?php
	header("content-type:text/html;charset=utf-8");
	//使用静态变量完成小孩游戏

	/*
	说,有一群小孩在玩堆雪人,不时有新的小孩加入,
请问如何知道现在共有多少人在玩?请使用面向
对象的思想，编写程序解决。

	*/
	

	class Child{
	
		public $name;
		//快速使用静态变量完成该游戏
		public static $count = 10;
		public function __construct($name){
			
			$this->name = $name;
		}
		//成员方法, 加入游戏
		public function joinGame(){
			echo '<br>' . $this->name . ' 加入游戏';
			//::范围解析符
			self::$count++;
		}

		//获取共有多少人玩游戏
		public function getTotalChild(){	
			//在类的内部可以使用 self 和 Child两种方式来访问
			//我们推荐使用 self::$静态属性名
			return self::$count;
//			return Child::$count;
			
		}
	}
	$child1 = new Child('贾宝玉');
	$child2 = new Child('林黛玉');
	
	$child1->joinGame();
	$child2->joinGame();
	
	echo '<br> 共有' . $child1->getTotalChild();

	echo '<br> 共有多少学生 ' . Child::$count;