<?php
	header("content-type:text/html;charset=utf-8");
	
	class Person{
		public $name;
		public $age;

		function __construct($name, $age){
			$this->name = $name;
			$this->age = $age;
		}
	}

	$p1 = new Person('小马', 9);
	echo $p1->name;

	//php 面向对象中，当你给一个不存在的属性赋值时，那么会临时给你增加一个对应属性，是pulbic
	$p1->sex = '男生';
	echo '性别' . $p1->sex ;