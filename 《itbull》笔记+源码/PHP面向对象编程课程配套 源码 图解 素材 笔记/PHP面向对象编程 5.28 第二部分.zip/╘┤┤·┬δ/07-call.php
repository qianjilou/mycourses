<?php
	header("content-type:text/html;charset=utf-8");
	//__call 魔术方法

	class Monkey{
		public $name;
		public $food;

		public function __construct($name, $food){
			
			$this->name = $name;
			$this->food = $food;
		}

		//成员函数
		public function showInfo(){
			echo $this->name . ' 喜欢吃 ' . $this->food;
		}

		//魔术方法
		/**
		@parameter $method 方法名
		@parameter $args 参数数组
		*/
		public function __call($method, $args){
//			echo '<pre>';
//			echo '__call ' . $method ;
//			echo '参数是';
//			print_r($args);
			
			if($method == 'play' ){
				return $this->$args[0]($args[1], $args[2]);
			}
			
			echo $method. '被调用';
			
		}

		//写一个成员方法
		public function getSum($n1, $n2){
			return $n1 + $n2;
		}

		protected function cry(){
			echo '妖猴在哭，要被收了';
		}
	}

	$monkey = new Monkey('妖猴', '小女孩');

	$monkey->showInfo();
	//在对象调用一个不可访问方法时(比如函数private/protected/或者不存在)，__call() 会被调用
	//$monkey->showInfo2(10, 40, 'hello,world!');
	
	$res = $monkey->play('getSum', 200, 400);
	echo 'res = ' . $res;

	$monkey->cry();
	
	//$monkey1->play('getSum', 200, 400);
	//$monkey1 调用的 play 方法，但是这个方法不存在. 
	//1. 调用 getSum方法，并获取和



