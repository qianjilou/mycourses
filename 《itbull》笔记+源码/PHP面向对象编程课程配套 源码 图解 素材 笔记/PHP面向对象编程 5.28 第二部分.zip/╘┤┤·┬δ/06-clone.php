<?php
	header("content-type:text/html;charset=utf-8");
	//看一个案例

	class Sheep{
		
		public $name;
		protected $food;

		function __construct($name, $food){
			$this->name = $name;
			$this->food = $food;
		}

		//克隆经典的使用场景时，就是单例模式时，防止克隆
		private function __clone(){
			echo '<br> __clone()被调用';
		}
	}

	//创建对象【第一种方式】
	$sheep1 = new Sheep('多利', '草');
	$sheep2 = new Sheep('多利', '草');
	echo '<pre>';
	var_dump($sheep1, $sheep2);

	//当对象之间使用 == 含义:
	//
	if($sheep1 == $sheep2){
		echo '<br> $sheep1 == $sheep2';
	}

	if($sheep1 === $sheep2){
		echo '<br> $sheep1 === $sheep2';
	}



	//第二种方式
	$sheep3 = $sheep1;
	if($sheep3 == $sheep1){
		echo '<br> sheep3 == $sheep1';
	}

	//
	if($sheep3 === $sheep1){
		echo '<br> sheep3 === $sheep1';
	}

	//第三种方式创建对象
	//当我们 clone 时，会触发一个魔术方法 ， __clone()
	echo '<hr><hr>';
	$sheep4 = clone $sheep1;

	$sheep4->name = '小白';

	
	var_dump($sheep4, $sheep1);
