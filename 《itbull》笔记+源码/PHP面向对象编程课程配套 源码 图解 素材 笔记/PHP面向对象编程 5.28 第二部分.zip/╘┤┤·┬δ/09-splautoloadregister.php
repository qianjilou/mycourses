<?php
	header("content-type:text/html;charset=utf-8");
	//spl_autoload_register 的使用

	//使用 spl_autoload_register 来注册我们自己的自动加载函数
	spl_autoload_register('myAutoLoad');
	
	
	$class_map = array(
		'Dog' => './model/Dog.class.php',
		'Cat' => './model/Cat.class.php',
		'Config' => './lib/Config.class.php',
	);


	function myAutoLoad($class_name){

		echo '<br> __autoload' . $class_name;
		//这里, 我们加载这个类就可以.
		//require  './' . $class_name . '.class.php';
		global $class_map;
		require $class_map[$class_name];

	}

	$cat = new Cat();
	$dog = new Dog();

	$cat->cry();