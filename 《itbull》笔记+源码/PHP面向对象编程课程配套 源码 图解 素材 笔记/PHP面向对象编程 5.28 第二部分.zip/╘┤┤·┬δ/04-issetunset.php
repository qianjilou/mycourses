<?php
	header("content-type:text/html;charset=utf-8");
	
	//__isset 和 __unset的使用

	class Cat{
		public $name;
		protected $food;
		private $sex;

		function __construct($name, $food, $sex){
			
			$this->name = $name;
			$this->food = $food;
			$this->sex = $sex;
		}

		//魔术方法
		function __isset($pro_name){
			
			echo '<br> __isset属性名为 ' . $pro_name;

			return isset($this->$pro_name);
		}

		//魔术方法
		function __unset($pro_name){
			//echo '<br> __unset' . $pro_name;
			//判断你要unset的属性是否存在
			if(isset($this->$pro_name)){
				unset($this->$pro_name);
			}else{
				echo '你要unset 不存在';
			}
		}

	}

	//创建一个对象
	$cat1 = new Cat('小花猫', '<。)#)))≦', '女生');

	//当我们判断某个成员属性是否存在

	echo ' $cat1->name 存在' . isset($cat1->name);
	
	//当你isset一个不可访问属性时，默认会调用魔术方法 __isset
	if(isset($cat1->food)){
		echo '<br> $cat1->food 存在'; 
	}else{
		echo '<br> $cat1->food 不存在'; 
	}

	//当你去unset一个不可访问属性时，默认会调用魔术方法 __unset

	unset($cat1->name);

	echo '<pre>';
	var_dump($cat1);


	unset($cat1->food);
	echo '<pre>';
	var_dump($cat1);

