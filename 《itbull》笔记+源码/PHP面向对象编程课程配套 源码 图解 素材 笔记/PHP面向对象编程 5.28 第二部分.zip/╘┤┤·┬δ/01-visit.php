<?php
	header("content-type:text/html;charset=utf-8");
	//这里我们讲解一下访问控制修饰符

	class Clerk{
		public $name; //名字，可以公开 public 
		protected $job;   //工作，是不公开， 是受保护 protected
		private $salary;  //薪水, 是私有, private;

		//构造函数
		function __construct($name, $job, $salary){
			
			$this->name = $name;
			$this->job = $job;
			$this->salary = $salary;
		}

		//成员方法
		public function getJob(){
			return $this->job;
		}

		public function getSalary(){
			return $this->salary;
		}
	}

	//创建一个对象
	$clerk1 = new Clerk('白骨精', ' PHP高级工程师', 30000);
	//访问
	//1. 如果你的属性是public的，则该属性可以在类外和类内部任意访问
	echo '<br> name = ' . $clerk1->name;

	//2. 如果你的属性是protected的，则该属性不可以在类外直接访问
	//如果你希望访问protected, 则你需要编写后一个成员方法(public)，来访问它
//	echo '<br> job = ' . $clerk1->job;
	echo '<br> job = ' . $clerk1->getJob();

	//3. 如果你的属性是private的，则该属性不可以在类外直接访问,如果你希望访问private, 则你需要编写后一个成员方法(public)，来访问它

//	echo '<br> salary =' . $clerk1->salary;

	echo '<br> salary =' . $clerk1->getSalary();
