<?php
	header("content-type:text/html;charset=utf-8");
	
	class Person{
		
		public $name;
		public static $total_fee = 900;
		public static function sayHello(){
			// 下面在static 方法中，去使用非静态变量，就错
			//echo '<br>hello, world!' . $this->name ;
		}
		
		//是一个普通的成员方法
		public function sayOk(){
			echo '<br> sayOk()' . self::$total_fee;
		}
	}

	$p1 = new Person();
	$p1->name = '泰牛';
	$p1->sayHello();
	$p1->sayOk();