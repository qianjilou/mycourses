<?php
	header("content-type:text/html;charset=utf-8");
	//静态方法

	class Student{
		
		public $name;
		private static $fee = 0.0;
		//构造函数
		function __construct($name){
			
			$this->name = $name;
		}
		//成员方法static , 交学费
		public static function fee($fee){
			//统计一下
			self::$fee += $fee;
		}

		//成员方法static , 获取学费
		public static function getFee(){
			echo '一共交了 '. self::$fee;	
		}
	}

	$student1 = new Student('犀牛精');
	$student1->fee(40000);
	$student2 = new Student('狐狸精');
	$student2->fee(60000);
	$student1->getFee();

