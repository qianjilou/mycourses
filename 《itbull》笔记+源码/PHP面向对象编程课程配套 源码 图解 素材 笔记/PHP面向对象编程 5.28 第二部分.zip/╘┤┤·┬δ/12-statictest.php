<?php
	header("content-type:text/html;charset=utf-8");
	//test
	//静态变量的初始化，不依赖于你是否创建了对象, 则我们的静态变量创建的时机和类的加载关联 . 类的加载 就是说你使用到类名
//	class Person{
//		public  static  $a=90;
//	}
//	echo Person::$a;

//	class Person{
//		public  static  $a=900;
//		public function  __construct(){
//			echo 'hello';
//		}
//	}
//	echo Person::$a;

	class Person{
		public  static  $a=90;
		public function  __construct(){
			echo 'hello';
		}
	}
	echo Person::$a;
	$p1=new Person(); 


