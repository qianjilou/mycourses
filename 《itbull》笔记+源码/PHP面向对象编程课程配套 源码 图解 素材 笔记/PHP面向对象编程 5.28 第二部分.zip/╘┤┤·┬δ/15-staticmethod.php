<?php
	header("content-type:text/html;charset=utf-8");
	//静态方法的注意事项

	class Person{
		
		

		public static function sayHello(){
			echo '<br>hello, world!';
		}
		public function sayOk(){
			//调用 sayHello
			//虽然下面的三种方法都 ok 
			//我们要求使用  self::sayHello();
			$this->sayHello();
			self::sayHello();
			Person::sayHello();
		}	
	}






	//1. 如果在类的外部调用静态方法，则要求该静态方法 是public
	Person::sayHello();
	$p1 = new Person();
	$p1->sayHello();
	//下面的方式虽然ok , 但是不推荐
	$p1::sayHello();
	echo '<hr>';
	$p1->sayOk();


