<?php
	header("content-type:text/html;charset=utf-8");
	//__toString 方法

	class Sheep{
		public $name;
		private $food;

		function __construct($name, $food){
			$this->name = $name;
			$this->food = $food;
		}

		//魔术方法(public)
		public function __toString(){
			return '<br> __toString()' . $this->name . ' 喜欢吃 ' . $this->food;
		}

	}

	//创建一个对象
	$sheep = new Sheep('喜洋洋', '青草');
	//当我们把一个对象，当做字符串使用，会调用__toString方法.
	echo $sheep;