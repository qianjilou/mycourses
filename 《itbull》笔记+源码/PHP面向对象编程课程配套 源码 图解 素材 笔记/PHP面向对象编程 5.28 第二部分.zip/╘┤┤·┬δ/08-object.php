<?php
	header("content-type:text/html;charset=utf-8");
	
	//类的成员方法，相互调用的一个方式
	class Person{
		
		public function sayHello(){
			echo '<br>sayHello';
			$this->sayOk();
		}

		public function sayOk(){
			
			echo '<br>sayOk';
		}
	}

	$p1 = new Person();
	$p1->sayHello();