<?php
	header("content-type:text/html;charset=utf-8");
	//一个问题的引入-》静态变量

	/*
	说,有一群小孩在玩堆雪人,不时有新的小孩加入,
请问如何知道现在共有多少人在玩?请使用面向
对象的思想，编写程序解决。

	*/

	$total_count = 0;

	class Child{
	
		public $name;
		
		public function __construct($name){
			
			$this->name = $name;
		}

		//成员方法, 加入游戏
		public function joinGame(){
			echo '<br>' . $this->name . ' 加入游戏';
			global $total_count;
			$total_count++;
		}

		//获取共有多少人玩游戏
		public function getTotalChild(){
			
			global $total_count;
			return $total_count;
		}
	}

	$child1 = new Child('贾宝玉');
	$child2 = new Child('林黛玉');
	$child3 = new Child('薛宝钗');
	$child1->joinGame();
	$child2->joinGame();
	$child3->joinGame();
	echo '<br> 共有' . $child1->getTotalChild();