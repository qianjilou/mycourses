<?php
	$arr = array(10,3,19,20,15,1,2, 0, -12);
		function Quiksort(&$arr){
		$len = count($arr);
		if($len <= 1){
			return $arr;
		}
		$flag = $arr[0];
		$arr_left = array();
		$arr_right = array();
		for($i = 1;$i < $len; $i++ ){
			if($arr[$i] <= $flag){
				$arr_left[] = $arr[$i];
			}else{
				$arr_right[] = $arr[$i];
			}
		}
		$arr_left = Quiksort(&$arr_left);
		$arr_right = Quiksort(&$arr_right);
		//$res = array_merge($arr_left,array($flag),$arr_right);
		return array_merge($arr_left,array($flag),$arr_right);

	}


	//这种形式不ok
	echo '<pre>';
	$res = Quiksort($arr);
	var_dump($res);
	var_dump ($arr);