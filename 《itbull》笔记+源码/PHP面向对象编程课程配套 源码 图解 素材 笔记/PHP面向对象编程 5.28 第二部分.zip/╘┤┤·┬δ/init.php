<?php
	header("content-type:text/html;charset=utf-8");
	//init.php 完成对类文件的加载

	//传统的方法

//	require './Dog.class.php';
//	require './Cat.class.php';

	//类的自动加载
	//当我们使用一个没有定义过的类，就会自动的触发这个函数
	//注意一个特点，就是 是动态加载的机制，当你使用到某个没有定义的类时，才会触发这个__autoload方法

	//在一个大项目中，我们可以做一个类的映射数组
	$class_map = array(
		'Dog' => './model/Dog.class.php',
		'Cat' => './model/Cat.class.php',
		'Config' => './lib/Config.class.php',
	);


	function __autoload($class_name){

		echo '<br> __autoload' . $class_name;
		//这里, 我们加载这个类就可以.
		//require  './' . $class_name . '.class.php';
		global $class_map;
		require $class_map[$class_name];

	}

	$cat = new Cat();
	$dog = new Dog();

	$cat->cry();