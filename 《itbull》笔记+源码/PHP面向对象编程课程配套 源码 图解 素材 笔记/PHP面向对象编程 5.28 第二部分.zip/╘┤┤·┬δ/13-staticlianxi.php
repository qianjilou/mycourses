<?php
	header("content-type:text/html;charset=utf-8");
	
	//唐僧师徒吃蛋糕
	/*
	请设计一个Person类, （有 名字， 年龄  和  蛋糕 三个属性）
蛋糕一共1000块，是所有人共享的.
创建唐僧师徒四人，他们每人都吃蛋糕, 唐僧每天吃 3块，悟空吃5块，沙和尚吃9块，猪八戒吃 30块. (编写一个 eat方法来吃)
问两天后，还剩多少块蛋糕，(编写一个 showCake() 来显示
	*/

	class Person{
		public $name;
		public $age;
		public static $cake_num = 1000;

		//构造函数
		function __construct($name, $age){
			$this->name = $name;
			$this->age = $age;
		}

		//成员方法
		public function eat($n){
			self::$cake_num -= $n;
		}

		//显示有多少块蛋糕
		public function showCake(){
			echo '<br>还有' . self::$cake_num . '蛋糕';
		}
	}

	$monk = new Person('唐僧', 90);
	$monkey = new Person('悟空', 500);
	$pig = new Person('八戒', 400);
	$shaseng = new Person('沙僧', 300);

	for($i = 0; $i < 20; $i++){

		$monk->eat(3);
		$monkey->eat(5);
		$shaseng->eat(9);
		$pig->eat(30);
	}

	echo $monk->showCake();