<?php
	header("content-type:text/html;charset=utf-8");
	//老太太养猫

	/*张老太养了两只猫猫:一只名字叫小白,今年3岁,白色。还有一只叫小花,今年10岁,花色。请编写一个程序，当用户输入小猫的名字时，就显示该猫的名字，年龄，颜色。如果用户输入的小猫名错误，则显示 张老太没有这只猫猫。*/

	$cat1_name = '小白'; 
	$cat1_age = 3; 
	$cat1_color = '白色';

	$cat2_name = '小花'; 
	$cat2_age = 10; 
	$cat2_color = '花色';

	//知道 $cat1_name ,然后依次输出
	//$cat1_age, $cat1_color;

	//从上面的代码看出，这样问题是，不利于数据管理
	echo $cat1_name. ' ' . $cat1_age . ' ' . $cat1_color;

	//如果我们使用面向对象的方式来解决，快速入门
	//下面就是一个类，最简单的定义
	class Cat{
		//我认为一只猫，有3个属性, 名字，年龄，和颜色
		public  $name;
		public $age;
		public $color;
	}

	//快速入门
	//通过猫类创建对应的实例(对象实例)

	//创建一个的猫对象
	$cat1 = new Cat();
	$cat1->name = '小红';
	$cat1->age = 9;
	$cat1->color = '红色';



	echo '<hr>';
	echo $cat1->name . ' ' . $cat1->age . ' ' . $cat1->color;


	$cat2 = new Cat();
	$cat2->name = '小黑';
	$cat2->age = 5;
	$cat2->color = '黑色';


	//定义一个人类
	class Person{
		public $name;
		public $age;
		public $sex;
		//....
	}





	
