<?php
	header("content-type:text/html;charset=utf-8");
	//看代码

	class Dog{
		public $name;
	}

	$dog1 = new Dog();
	$dog1->name = '大黄';
	$dog2 = $dog1;
	$dog2 = 'abc';
	
	echo '<br>' . $dog1->name;
	echo '<br>' . $dog2;