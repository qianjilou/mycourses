<?php
	header("content-type:text/html;charset=utf-8");
	//$this的说明示意图
	class Pig{	
		public $name;
		public function __construct($name){
			$this->name = $name;
		}
		//显示名
		public function showInfo(){
			echo 'name = ' . $this->name;
			echo '<pre>';
			var_dump($this);
		}
	}
	echo '<pre>';
	$pig1 = new Pig('宠物猪');
	var_dump($pig1);
	$pig1->showInfo();
	

	$pig2 = new Pig('小花猪');
	var_dump($pig2);
	$pig2->showInfo();