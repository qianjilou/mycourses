<?php
	header("content-type:text/html;charset=utf-8");
	//插入排序法

	//$arr = array(10, 7, 1);

	$arr = array();
	for($i = 0; $i < 10000; $i++){
		
		$arr[] = rand(1, 8000);
	}
	//插入排序函数
	function insertSort(&$arr){
		
		//确定大循环的次数
		$arr_size = count($arr);
	
		//从$i = 1 这个数，加入到我们的有序数组
		for($i = 1; $i < $arr_size; $i++){
			
			//先把 $arr[$i],保存到$insertVal变量
			$insertVal = $arr[$i];
			//$index 是你的有序数组的最后那一个元素的下标
			$index = $i - 1;	
			while($index >= 0 && $arr[$index] > $insertVal){
				
				//将这个 $index 对应的元素后移
				$arr[$index + 1] = $arr[$index];
				$index--;
			}
				
			//将我们的$insertVal 值，让到 $index+1 的位置即可
			$arr[$index + 1] = $insertVal;
		}
	}

	date_default_timezone_set('PRC');
	echo '<br>排序前' . date('H:i:s');
	insertSort($arr);
	echo '<br>排序后' . date('H:i:s');
	echo '<pre>';
	print_r($arr);