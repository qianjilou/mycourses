<?php
	header("content-type:text/html;charset=utf-8");
	//对象的传递机制说明

	class Person{
		
		public $name;
		public $age;
	}

	//创建对象
	$person1 = new Person();
	$person1->name = '小吴';

	echo '<hr> $person1的对象标识符';
	echo '<Pre>';
	var_dump($person1);

	$person2 = $person1;
	$person1->name = '老吴';
	
	echo '$person2->name=' . $person2->name;
