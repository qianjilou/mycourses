<?php
	header("content-type:text/html;charset=utf-8");
	
	//默认构造函数
	class Cat{
		
		public $name;
		
		//默认构造函数
		

	}

	$cat1 =new Cat();