<?php
	header("content-type:text/html;charset=utf-8");
	//快速排序
	

	//$array=array(-9,78,0,23,-567,89);

	//构建一个10000个元素的无序数组
	$array = array();
	for($i = 0; $i < 400000; $i++){
		$array[] = rand(1, 8000);
	}
	//函数
	function quickSort($left,$right,&$array){
			$l=$left;
			$r=$right;
			$pivot = $array[($left+$right)/2];
			$temp=0;
			
			while($l<$r){
				
				while($array[$l]<$pivot) $l++;
				while($array[$r]>$pivot) $r--;
				
				
				if($l>=$r) break;
				
				$temp=$array[$l];
				$array[$l]=$array[$r];
				$array[$r]=$temp;
				
				if($array[$l]==$pivot) --$r;
				if($array[$r]==$pivot) ++$l;
				
							
			}
			

			if($l==$r){
				 
				 $l++;
				 $r--;
			}
			
			if($left<$r)  quickSort($left,$r,$array);
			if($right>$l) quickSort($l,$right,$array);
						
			}
	
	date_default_timezone_set('PRC');
	echo '<br>排序前' . date('H:i:s');
	quickSort(0,count($array)-1,$array);
	echo '<br>排序后' . date('H:i:s');
	echo '<pre>';
	//print_r($array);
?>
