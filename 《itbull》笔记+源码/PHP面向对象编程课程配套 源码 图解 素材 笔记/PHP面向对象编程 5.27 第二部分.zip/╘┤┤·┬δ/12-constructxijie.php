<?php
	header("content-type:text/html;charset=utf-8");
	//关于构造函数再说明 

	class Cat{
		public $name;
		
		//默认构造函数

		//自定义了一个构造函数
		//当(1)一旦自定义了一个构造函数，默认的
		//构造函数就被覆盖了,这时在创建对象的时候就要使用自定义的构造函数.
		public function __construct($name){
			
			echo 'hello,泰牛';
		}
		//一个类只能有一个构造函数
		public function __construct($name, $age){		
		}

	}

	$cat = new Cat('小马');