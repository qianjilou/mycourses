<?php
	header("content-type:text/html;charset=utf-8");
	//在创建人类对象时，直接可以指定属性值

	class Person{
		
		public $name;
		public $age;

		//构造函数
		public function __construct($my_name, $my_age){
			
			//如果使用这种方式来赋值，其实$name是一个局部变量
//			$name = $my_name;
//			$age = $my_age;
			
			
			//正确写法是
			//$this 他表示的就是当前的对象
			// 谁调用我，$this 就指向谁
			$this->name = $my_name;
			$this->age = $my_age;
			echo '<br> this <pre>' ;
			var_dump($this);

		}

		//成员方法, 当我调用函数，可以显示对象的信息
		public function showInfo(){
			echo '信息如下:<br>';
			echo $this->name . ' ' . $this->age;
		}
	}

	//创建一个对象实例
	$person = new Person('猪八戒', 200);

	

	echo '<br> person is ';
	var_dump($person);

	echo '<br> ' . $person->name . ' age = ' . $person->age;

	$person->showInfo();
	
	


	echo '<hr>';
	//创建一个对象实例
	$person2 = new Person('沙和尚', 100);

	echo '<br> person is ';
	var_dump($person2);

	$person2->showInfo();