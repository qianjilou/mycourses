<?php
	header("content-type:text/html;charset=utf-8");
	//构造函数的细节

	//①没有返回值
	//②在创建一个类的新对象时，系统会自动的调用该类的构造方法完成对新对象的初始化。
	//3. 在php4中，他的构造函数和类名一样
	//4. php5中不但支持php4中构造函数，同时还增加了另外一种方式__construct
	//5. 默认构造函数的说明(当你没有写任何构造函数时，会默认给你一个函数)
	class Cat{
		
		public $name;
		//php4中构造函数和类名一样
		/*public function Cat($name){
			$this->name = $name;
		}*/
		//php 5 中，我们使用的是 __construct方式来定义构造函数
		public function __construct($name){
			echo '<br>  __construct 被调用';
			$this->name = $name;
		}
	}

	$cat1 =new Cat('小小花猫');
	echo $cat1->name;
