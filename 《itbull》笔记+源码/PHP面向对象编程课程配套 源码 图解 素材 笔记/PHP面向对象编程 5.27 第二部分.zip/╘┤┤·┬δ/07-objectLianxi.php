<?php
	header("content-type:text/html;charset=utf-8");
	//关于使用& 来传递对象的案例

	class Dog{
		public $name;
	}

	$dog1 = new Dog();
	$dog1->name = '大狼狗';

	$dog2 = &$dog1;

	echo '<br>'  . $dog1->name . $dog2->name; 

	$dog2 = 'def';

	echo '<br>' . $dog1->name;
	echo '<br>' . $dog1;
	echo '<br>' . $dog2;
