<?php
	header("content-type:text/html;charset=utf-8");
	//成员函数的讲解

	/*
	   ①添加speak 成员方法,输出 我是一个好人
   ②添加jisuan 成员方法,可以计算从 1+..+1000的结果
   ③修改jisuan 成员方法,该方法可以接收一个数n，计算 1+..+n 的结果
   ④添加add 成员方法,可以计算两个数的和

	*/

	class Person{
		public $name;
		public $age;
		
		//添加speak 成员方法,输出 我是一个好人
		public function speak(){
			echo '<br> 我是一个好人';
		}

		//添加jisuan 成员方法,可以计算从 1+..+1000的结果
		public function jiSuan(){
			
			$res = 0;
			for($i = 1; $i <= 1000; $i++){
				
				$res += $i;
			}

			echo '<br> 运算结果是' . $res; 
		}

		//修改jisuan 成员方法,该方法可以接收一个数n，计算 1+..+n 的结果
		public function jiSuan2($n){
			
			$res = 0;
			for($i = 1; $i <= $n; $i++){
				
				$res += $i;
			}

			echo '<br> 运算结果是' . $res; 
		}

		//添加add 成员方法,可以计算两个数的和
		public function add($n1, $n2){
			
			return $n1 + $n2;
		}


	}

	//看看如何使用成员函数
	$person = new Person();
	$person->name = '孙悟空';
	//调用成员函数
	$person->speak();
	
	//添加jisuan 成员方法,可以计算从 1+..+1000的结果
	$person->jiSuan();


	$person->jiSuan2(10);

	$res = $person->add(10, 20);
	echo '<br> add函数调用的结果是' . $res;


