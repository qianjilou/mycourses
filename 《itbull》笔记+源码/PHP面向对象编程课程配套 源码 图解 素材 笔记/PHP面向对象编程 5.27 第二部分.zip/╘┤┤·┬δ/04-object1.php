<?php
	header("content-type:text/html;charset=utf-8");
	
	//关于类的使用说明
	class Person{
		
		public $name;
	}

	$person1 = new Person();

	$person1 = new PERSON();


