<?php
	header("content-type:text/html;charset=utf-8");
	//析构函数
	class Person{
		public $name;
		
		//构造函数
		function __construct($name){
			$this->name = $name;
		}
		//析构函数
		function __destruct(){

			echo '<br> .' . $this->name . ' 析构';
		}
	}

	//在默认情况下，先创建的对象后销毁，后创建的对象先销毁
	$p1 = new Person('zs');	
	$p2 = new Person('ww');
	$p4 = &$p2;
	$p4 = 'abc';
	$p3 = new Person('lisi');