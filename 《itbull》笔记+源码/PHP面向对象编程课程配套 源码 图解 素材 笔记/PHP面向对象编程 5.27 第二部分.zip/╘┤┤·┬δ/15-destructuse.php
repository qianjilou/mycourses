<?php
	header("content-type:text/html;charset=utf-8");
	//析构函数的最佳实践

	class DAOMysql{
		
		//有一系列的成员变量
		public $user_name;
		public $password;
		public $host;
		public $my_link;

		//构造函数
		function __construct(){
			
			//创建的时候，我们初始化的成员变量..数组

			$this->my_link = @mysql_connect('localhost', 'root', 'root');
		}

		function __destruct(){
			//这里我们可以在析构函数中，手动的销毁数据库连接
			//@mysql_close($this->my_link);
			echo '<br> 对象被销毁';
		}

	}

	$dao = new DAOMysql();
	//使用$dao
	
	mysql_select_db('tnblog');
	$sql = 'SELECT * FROM user';
	$res = mysql_query($sql, $dao->my_link);
	while($row = mysql_fetch_assoc($res)){
		echo '<pre>';
		var_dump($row);
	}


	//我们不再使用$dao
	//通过该方法，可以及时的释放重量级的对象
	$dao = null;

	@mysql_select_db('tnblog');
	$sql = 'SELECT * FROM user';
	$res = @mysql_query($sql);
	while($row = @mysql_fetch_assoc($res)){
		echo '<pre>';
		var_dump($row);
	}

	//有很多其它的代码
	//....
	//....
	//....
	//....
	//....
	//....
	//....
	//....
	//....
	//....
	//....
	//....
	//....
	//....
	//....
	//....
	//....
	//....
	//....
	//....

