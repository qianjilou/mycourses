<?php
	header("content-type:text/html;charset=utf-8");
	//php的重载实现

	/*
	通过 $对象名->getVal(1, 2)  则实现求出两个数的和
	通过 $对象名->getVal(34, 89, 90) 则返回三个数中最大的那个数
	//思路: getVal 在Bull类没有，当我们调用getVal时，就去触发__call魔术方法, 然后在 __call实现
	
	*/

	class Bull{
		
		public $name;

		public function __construct($name){
			$this->name = $name;
		}

		//求出最大值
		private function getMax($n1, $n2, $n3){
		
			return max($n1, $n2, $n3);
		}
		//求和
		private function getSum($n1, $n2){
			return $n1 + $n2;
		}

		public function __call($method, $args){
			//echo '<br> __call($method, $args)';

			//判断你调用的是不是 getVal函数
			if($method == 'getVal'){
				//判断$args的参数个数
				if( 2 == count($args)){
					//调用求和
					if(is_numeric($args[0]) && is_numeric($args[1])){
						return $this->getSum($args[0], $args[1]);
					}else{
						return '你的参数有误，请重新输入';
					}
				}else if(3 == count($args)){
					//调用求最大值
					if(is_numeric($args[0]) && is_numeric($args[1]) && is_numeric($args[2])){
						return $this->getMax($args[0], $args[1], $args[2]);
					}else{
						return '你的参数有误，请重新输入';
					}
				}
			}
		}
		
	}


	$bull1 = new Bull('牛魔王');
	//求出和
	echo '<br> 和=' . $bull1->getVal(10, 40);
	//求出最大值
	echo '<br> 最大值 = ' . $bull1->getVal(30, 40, 170);



