<?php
	header("content-type:text/html;charset=utf-8");
	
	//传统的重载的含义

	class Cat{
		

		public function getVal($n1){
			
			return 2 * $n1;
		}

		//在php中，不允许存在相同函数名
		public function getVal($n1 , $n2){
		
			return $n1 + $n2;
		}
	}

	$cat1 = new Cat();
	
	$cat1->getVal(10);
	$cat1->getVal(10, 20);

