<?php
	header("content-type:text/html;charset=utf-8");
	//继承的讲解

	
	//为了简化代码,我们创建一个父类 Student
	//父类
	class Student{
		
		public $name;
		public $sex;
		protected $fen;

		//构造函数
		public function __construct($name, $sex){
			$this->name = $name;
			$this->sex = $sex;
		}
		//成绩
		public function setFen($fen){
			$this->fen = $fen;
		}

		//显示成绩的方法
		public function showFen(){
			echo  '<br>' . $this->name . ' 考了' .$this->fen;
		}
	}

	//小学生类
	class Pupil extends Student{
	
		//考试
		public function testing(){
			echo '<br> 小学生考试，考的的小学数学...';
		}	
	}

	//大学生类
	class Graduate extends Student{
			
		//考试
		public function testing(){
			echo '<br> 大学生考试，考的的微积分...';
		}

		
	}

	//上面的代码，是可以使用的，但是复用性和维护性不好

	//使用
	//需要输出考试成绩
	$pupil = new Pupil('花仙子', '女生');
	$pupil->testing();
	$pupil->setFen(100);
	$pupil->showFen();


	$graduate = new Graduate('黑猫警长', '男生');
	$graduate->testing();
	$graduate->setFen(59);
	$graduate->showFen();







