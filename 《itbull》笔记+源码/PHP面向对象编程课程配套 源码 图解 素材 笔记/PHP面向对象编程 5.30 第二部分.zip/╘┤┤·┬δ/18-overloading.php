<?php
	header("content-type:text/html;charset=utf-8");
	//静态函数的重载

	
	class Bull{
		
		public $name;

		public function __construct($name){
			$this->name = $name;
		}

		//求出最大值
		private static function getMax($n1, $n2, $n3){
		
			return max($n1, $n2, $n3);
		}
		//求和
		private static function getSum($n1, $n2){
			return $n1 + $n2;
		}

		public static function __callStatic($method, $args){

			
			echo '<br> __callStatic($method, $args)';

			//判断你调用的是不是 getVal函数
			if($method == 'getVal'){
				//判断$args的参数个数
				if( 2 == count($args)){
					//调用求和
					if(is_numeric($args[0]) && is_numeric($args[1])){
						return self::getSum($args[0], $args[1]);
					}else{
						return '你的参数有误，请重新输入';
					}
				}else if(3 == count($args)){
					//调用求最大值
					if(is_numeric($args[0]) && is_numeric($args[1]) && is_numeric($args[2])){
						return self::getMax($args[0], $args[1], $args[2]);
					}else{
						return '你的参数有误，请重新输入';
					}
				}
			}

		
		}
		
	}


	$bull1 = new Bull('牛魔王');
	//求出和
	echo '<br> 和=' . Bull::getVal(11, 40);
	//求出最大值
	echo '<br> 最大值 = ' . Bull::getVal(30, 40, 170);



