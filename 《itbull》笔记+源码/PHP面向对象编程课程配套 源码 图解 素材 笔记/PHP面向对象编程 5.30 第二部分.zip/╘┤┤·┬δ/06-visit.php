<?php
	header("content-type:text/html;charset=utf-8");
	//如何访问 protected 和 private 的属性
	//第一种方法 __set 和 __get

	class Person{
		
		public $name;
		protected $nickname;
		private $address;

		function __construct($name, $nickname, $address){
			$this->name = $name;
			$this->nickname = $nickname;
			$this->address = $address;
		}
		//魔术方法
		public function __get($pro_name){

			//判断属性存在否
			if(isset($this->$pro_name)){
				return $this->$pro_name;
			}else{
				return '属性不存在';
			}
		}

		public function __set($pro_name, $val){
			//判断属性是否存在
			if(isset($this->$pro_name)){
				$this->$pro_name = $val;
			}else{
				return '属性不存在';
			}
		}
	}

	$person1 = new Person('宋江', '及时雨', '水泊梁山');

	echo 'nickname' . $person1->nickname;
	$person1->nickname = '智多星';
	echo '<br> nickname' . $person1->nickname;