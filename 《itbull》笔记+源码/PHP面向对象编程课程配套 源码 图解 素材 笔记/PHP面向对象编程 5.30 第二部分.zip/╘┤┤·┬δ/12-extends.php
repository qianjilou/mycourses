<?php
	header("content-type:text/html;charset=utf-8");
	//继承细节说明
	class Person{
		
		public $name = '泰牛';
		protected $age = 10;
		private $salary = 90.4;

		public function abc1(){
			echo '<br> abc1()';
		}

		protected function abc2(){
			echo '<br> abc2()';
		}

		private function abc3(){
			echo '<br> abc3()';
		}
	}

	class Student extends Person{
		
		public $address = '唐家岭';  
	

		//父类的public修饰符的属性和方法,protected修饰符的属性和方法被子类继承了并可以访问 
		public function showInfo(){
			echo '<br>信息如下:<br>';
		//	echo 'name=' . $this->name . ' age = '. $this->age . ' salary = ' . $this->salary;
			echo 'name=' . $this->name . ' age = '. $this->age ;
		}

		public function useMethod(){
			$this->abc1();
			$this->abc2();
			//$this->abc3();
		}
	}

	//创建一个学生对象
	$student = new Student;
	echo '<pre>';
//	var_dump($student);
	$student->showInfo();

	$student->useMethod();