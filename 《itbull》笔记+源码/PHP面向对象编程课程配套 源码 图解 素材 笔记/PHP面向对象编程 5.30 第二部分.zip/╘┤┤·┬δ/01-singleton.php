<?php
	header("content-type:text/html;charset=utf-8");
	//单例模式的讲解

	//这里这个工具类，是用于操作数据库，因此是一个重量级的类->对象也是重量级，因此控制它只有一个对象实例
	class DBHelper{
	
		// $conn 是一个数据库连接
		private $conn;
		// 定义一个静态属性, 表示一个 DBHelper 实例 
		private static $instance = null;
		
		//构造函数
		private function __construct(){
			
			$this->conn = @mysql_connect('localhost', 'root', 'root');
		}

		//静态方法, 通过方法，可以获取一个对象实例
		public static function getSingleton(){
			
			//第一种写法
			if(self::$instance == null ){
				//实例化
				self::$instance  = new DBHelper();
			}
			return self::$instance;

		}

		//为了防止克隆，我将__clone private
		private function __clone(){

		}

		public function query($sql){
			
			echo '<br>完成对数据库的操作....';
		}

	}

//	$db1 = new DBHelper();
//	$db2 = new DBHelper();
	
	$db1 = DBHelper::getSingleton();
	$db2 = DBHelper::getSingleton();
	
	

	echo '<pre>';

	if($db1 === $db3){
		echo '<br>$db1 === $db2';
	}else{
		echo '$db1  和 $db2 不是同一个对象';
	}

