<?php
	header("content-type:text/html;charset=utf-8");
	//单例模式的讲解

	//这里这个工具类，是用于操作数据库，因此是一个重量级的类->对象也是重量级，因此控制它只有一个对象实例
	class DBHelper{
	
		// $conn 是一个数据库连接
		private $conn;
		
		//构造函数
		public function __construct(){
			
			$this->conn = @mysql_connect('localhost', 'root', 'root');
		}

		public function query($sql){
			
			echo '<br>完成对数据库的操作....';
		}

	}

	$db1 = new DBHelper();
	$db2 = new DBHelper();

	echo '<pre>';

	if($db1 === $db2){
		echo '<br>$db1 === $db2';
	}else{
		echo '$db1  和 $db2 不是同一个对象';
	}

