<?php
	header("content-type:text/html;charset=utf-8");
	//讲解 封装实现-三种访问控制符

	class A{
		
		//三种属性
		public $n1 = 10;
		protected $n2 = 20;
		private $n3 = 30;

		//三种方法
		public function getN1(){
			
			return '$n1 = ' . $this->n1;
		}

		protected function getN2(){
			return '$n2 = ' . $this->n2;
		}

		private function getN3(){
			return  '$n3 = ' . $this->n3;
		}

		//这里，我们使用一个方法来访问 属性
		//说明  三种访问控制符的属性，可以在本类访问到
		public function getInfo(){
			
			echo '<br> getInfo()' . $this->n1 . ' n2= ' . $this->n2 . ' n3=' . $this->n3;
		}

		//这里，三种访问控制符的方法，可以在本类访问到

		public function showAll(){
			echo $this->getN1();
			echo $this->getN2();
			echo $this->getN3();
		}
	}


	$a = new A();

	echo '<br> 在类的外部 访问共有的属性 ' . $a->n1;
	//echo '<br> 在类的外部 访问protected属性 ' . $a->n2;
	//echo '<br> 在类的外部 访问private的属性 ' . $a->n3;

	echo '<hr>';

	echo '<br> 在类的外部 访问public的方法' . $a->getN1();
	//echo '<br> 在类的外部 访问protected的方法' . $a->getN2();
	//echo '<br> 在类的外部 访问private的方法' . $a->getN3();

	echo '<hr>';

	//
	$a->getInfo();
	$a->showAll();

