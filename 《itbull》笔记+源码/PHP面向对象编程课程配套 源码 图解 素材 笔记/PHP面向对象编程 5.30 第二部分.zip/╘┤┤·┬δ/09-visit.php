<?php
	header("content-type:text/html;charset=utf-8");
	

	class A{
		
		//如果是普通的属性，则一定要有访问修饰符
		public $name = 0;
		//如果 是 var 则表示public
		var $age = 0;
		//如果属性是静态属性，可以不写访问修饰符，则默认是public
		static $total_num = 0;

		//当我们的函数，没有写访问修饰符，则默认为public
		function abc(){
		}

		function __construct(){
			
		}
	}

	$a = new A();