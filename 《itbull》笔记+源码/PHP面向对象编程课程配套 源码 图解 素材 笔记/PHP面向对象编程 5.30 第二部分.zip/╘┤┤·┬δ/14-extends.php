<?php
	header("content-type:text/html;charset=utf-8");
	//继承的细节

	class A{

		public $name = 'hello';
	}

	class B extends A{

		public $age = 90;
	}

	class C extends B{
	}

	$c = new C();
	
	echo $c->age . ' name =' . $c->name;