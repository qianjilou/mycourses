<?php
	header("content-type:text/html;charset=utf-8");
	
	//写段代码

	class Goods{
		public $goods_name;
		public $price;
		public function  getPrice(){
			return $this->price;
		}
	}

	class Book extends Goods{
		
		public  $author;
		public  $publisher;

	}

	$book1 = new Book();
	$book1->author = '吴承恩';
	$book1->publisher= '清华出版社';
	$book1->goods_name = '西游记';
	$book1->price = 57.9;

	echo $book1->getPrice();
