<?php
	header("content-type:text/html;charset=utf-8");
	//对象运算符的连续使用

	//学生类
	class Student{
		
		public $name;
		private $school;

		//setSchool
		public function setSchool($school){
			
			$this->school = $school;
		}
		//get School
		public function getSchool(){
			return $this->school;
		}
	}

	//学校类
	class School{
		public $name;
		protected $address;
		private $my_class;

		public function setClass($my_class){
			
			$this->my_class = $my_class;
		}

		public function getClass(){
		
			return $this->my_class;
		}
	}

	//班级类
	class MyClass{
		public $name;
		public $class_num;

		//构造函数
	}

	$my_class = new MyClass;
	$my_class->name = 'PHP大牛二期班';
	$my_class->class_num = 108;

	$my_school = new School();
	$my_school->name = '泰牛程序员';
	$my_school->setClass($my_class);

	$my_student = new Student();
	$my_student->name = '小键';
	$my_student->setSchool($my_school);

	//这时，如果我们希望查看$my_student 的班级信息

	echo '小键 所在班级名称是=' .$my_student->getSchool()->getClass()->name;





