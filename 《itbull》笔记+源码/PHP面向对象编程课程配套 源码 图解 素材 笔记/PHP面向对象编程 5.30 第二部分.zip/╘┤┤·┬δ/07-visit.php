<?php
	header("content-type:text/html;charset=utf-8");
	//如何访问 protected 和 private 的属性
	//第二种方法 getXxx 和 setXxx

	class Book{
		public $book_name;
		public $author;
		public $price;
		private $amount = 0;

		public function __construct($book_name, $author, $price){
			$this->book_name = $book_name;
			$this->author = $author;
			$this->price = $price;
		}

		//针对$amount 提供 方法
		public function setAmount($num){
				
			if(is_int($num)){
				$this->amount = $num;
			}else{
				echo '数据有问题，请重新输入';
			}
		
		}

		public function getAmount($code){
			
			if($code == 'itbull'){
				return $this->amount;
			}else{
				return '密码错误';
			}

		}
	}

	//创建一本书
	$book1 = new Book('红楼梦', '小曹', 56.8);

	$book1->setAmount(2000);
	echo $book1->getAmount('itbul');

