<?php
	header("content-type:text/html;charset=utf-8");
	
	class Movie{
		public $name;
		public $director;
		protected $cost;
		private $piao_fang;

		public function __construct($name, $director, $cost, $piao_fang){
			$this->name = $name;
			$this->director = $director;
			$this->cost = $cost;
			$this->piao_fang = $piao_fang;
		}

		//提供一个查询信息的函数
		public function query(){
//			if($code == '123'){
//				echo $this->name . ' ' . $this->cost . ' ' . $this->piao_fang ;
//			}
			echo $this->name . ' ' . $this->cost . ' ' . $this->piao_fang ;
		}
	}

	$movie = new Movie('美人鱼', '周星驰', 150000000, 3000000000);

	$movie->query();

