<?php
	header("content-type:text/html;charset=utf-8");
	//封装快速入门

	class Clerk{
		
		public $name;
		protected $job;
		private $salary;

		//构造函数
		public function __construct($name, $job, $salary){
			
			$this->name = $name;
			$this->job = $job;
			$this->salary = $salary;
		}

		//提供一个函数[提供接口]，来访问job
		public function getJob($pwd){
			
			//体现封装验证
			if($pwd == '123'){
				return $this->job;
			}else{
				return '你没有查看的权限!';
			}
		}

	}

	//创建一个职员
	$clerk =new Clerk('老王', 'PHP项目经理', 23000.45);
	echo 'name = ' . $clerk->name;
	echo '<br>job =' . $clerk->getJob('123');