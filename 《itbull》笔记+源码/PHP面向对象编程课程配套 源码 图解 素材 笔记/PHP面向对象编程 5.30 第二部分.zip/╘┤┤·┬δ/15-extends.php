<?php
	header("content-type:text/html;charset=utf-8");
	//继承细节 在创建某个子类对象时，默认情况下会自动调用其父类的构造函数(指在子类没有自定义构造函数情况时)

	class A{
		//构造函数
		public function __construct(){
			echo '<br>  A __construct()';
		}

		public function sayHello(){
			echo '<br> AAA sayHello';
		}
	}

	class B extends A{
	
		//如果，子类没有构造函数，择子类继承父类的构造函数
		//如果子类有构造函数，则子类的构造函数，就重写父类的构造函数
		public function __construct(){
			echo '<br> B __construct()';
			//在子类调用父类的(public protected)方法, 有这样的原则
			//如果调用父类的普通的成员方法，我们使用 $this->方法名
			//或者 parent::方法名 , 我们调用是构造方法，我们使用parent::__construct();
			
			//有三种方式
			//$this->sayHello();
			//A::sayHello();
			//parent::sayHello();

			//如果是调用构造方法
			//parent::__construct();
			
		}

	}

	$b = new B();