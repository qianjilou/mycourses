<?php
	header("content-type:text/html;charset=utf-8");
	//练习-保证只能创建一只猫

	class Cat{
		
		public $name;
		//$instance 表示 Cat的一个对象实例
		private static $instance = null;

		//为了防止，用户直接 new 对象
		//因此将 构造函数做成private
		private function __construct($name){
			
			$this->name = $name;
		}

		//一个静态方法 public , 通过该方法，我们可以获取一个对象实例
		public static function getSingleton($name){
			
			//判断  $instance 属性是否已经创建过
			if(!(self::$instance instanceof self)){
				//说明没有创建过 , 在类的内部，可以通过 new self方法来调用
				self::$instance = new self($name);
			}

			return self::$instance;
		}

		//防止克隆
		private function __clone(){
		}

	}

//	$cat1 = new Cat('波斯猫');
	$cat1 = Cat::getSingleton('波斯猫');
	$cat2 = Cat::getSingleton('加菲猫');

	echo '<br> cat1->name = ' . $cat1->name;
	echo '<br> cat2->name = ' . $cat2->name;
