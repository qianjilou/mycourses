<?php
	header("content-type:text/html;charset=utf-8");
	//练习
	
//	class Animal{
//		public $name;
//		public function cry(){
//		echo '动物叫唤...';
//		}
//	}
//	
//	class Dog extends Animal{
//		//这里有一个重写的要求，重写的时候，子类的函数名
//		//参数的个数一样，才可以.
//		public function cry($name){
//			echo '小狗汪汪叫唤..';
//		}
//	}
//
//	$dog1=new Dog();
//	$dog1->cry('abc');

	class Animal{
		protected function cry()
		{
			echo '动物叫唤..';
		}
	}
	class Cat extends Animal{
		public function cry(){
		  echo '猫猫叫唤..';
		  //Animal::cry();
		}
	}
	$cat1=new Cat();
	$cat1->cry();

