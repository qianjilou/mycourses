<?php
	header("content-type:text/html;charset=utf-8");
	//final 讲解

	//如果不希望其它的子类来继承 SuperMan
	final class SuperMan{
		
		public $name;
		public $ability;

		//不让子类重写我们的attact方法
		final public function attact(){
			echo '<br>超人的攻击方式: 原子弹...';
		}
	}


	class GangTieXia extends SuperMan{
		public function myAttact(){
			echo '<br> 使用氢弹...';
		}
	}