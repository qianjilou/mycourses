<?php
	header("content-type:text/html;charset=utf-8");
	//接口练习

	class Monkey{
		
		public $name;
		function __construct($name){
			$this->name = $name;
		}

		//爬树
		function climbing(){
			echo '<br> 猴子爬树...';
		}
	}

	interface iBirdable{
		public function flying();
	}

	interface iFishable{
		public function swimming();
	}
	
	//可以这样理解，接口机制，是对php单继承的补充..
	//它可以在不破坏继承关系的基础上，对某个子类功能进行扩展
	class LittleMonkey extends Monkey implements iBirdable, iFishable{
		
		public function flying(){
			echo '<br> 小猴学会飞翔...';
		}
		
		public function swimming(){
			
			echo '<br> 小猴子学会游泳..';
		}

	}

	$littleMonkey  = new LittleMonkey('孙悟空');
	$littleMonkey->climbing();
	$littleMonkey->flying();
	$littleMonkey->swimming();
