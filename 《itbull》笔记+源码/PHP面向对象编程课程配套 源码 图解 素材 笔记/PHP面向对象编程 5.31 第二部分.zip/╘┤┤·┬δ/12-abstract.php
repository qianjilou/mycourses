<?php
	header("content-type:text/html;charset=utf-8");
	
//	abstract class A{
//	}
//
//	$a = new A();


	//抽象类，可以没有abstract方法，也可以有。
	//同时也可以有实现过的方法
//	abstract class B{
//		public $num = 10;
//		const TAX_RATE = 0.08;
//		public static $total_num = 10;
//		public function sayHello(){
//			echo 'b sayHello()';
//		}
//	}


	//一旦类包含了abstract方法,则这个类必须声明为abstract 
//	abstract class C{
//	
//		abstract function abc();
//	}


	abstract class A{
		abstract function getSum($n1, $n2);
	}


	//这里，B类必须把A类的所有的抽象方法实现
	class B extends A{		
		function getSum($n1,$n2){
		
			return $n1 + $n2;
		}


	}

	//这里，如果C类 不实现 A类的所有的抽象方法实现
	//则，C类也必须声明为abstract
	abstract class C extends A{	
		
		abstract function sayOk();
	}

	class D extends C{
		//D需要实现哪里几个方法
		//abstract function getSum($n1, $n2);
		//abstract function sayOk();

		function getSum($n1, $n2){
			return $n1 + $n2;
		}

		function sayOk(){
			echo 'sayok';
		}
	}





