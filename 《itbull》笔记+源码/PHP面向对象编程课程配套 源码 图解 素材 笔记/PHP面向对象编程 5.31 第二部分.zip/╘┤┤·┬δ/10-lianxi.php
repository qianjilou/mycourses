<?php
	header("content-type:text/html;charset=utf-8");
	//练习类名可以是一个变量

	class Dog{
		
	}

	$dog1 = new Dog();

	$var = 'Dog';
	$dog2 = new $var();
	echo '<Pre>';
	var_dump($dog2);