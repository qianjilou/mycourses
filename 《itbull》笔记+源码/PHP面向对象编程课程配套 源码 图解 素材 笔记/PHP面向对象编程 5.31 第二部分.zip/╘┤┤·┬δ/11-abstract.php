<?php
	header("content-type:text/html;charset=utf-8");
	
	//抽象类
	abstract class Animal {
		
		//如果一个类，有一个方法，不确定，
		//1. 这时我们可以把这个方法声明为抽象, 则需要在前面 写上 abstract, 
		//2. 被声明为abstract 的方法，不能有方法体
		//3. 如果一个类中，只要含有一个抽象方法，则该类必须声明为abstract
		//4. 抽象类重点在设计，他的作用是让其它类来继承它，并实现它的方法.
		abstract public function cry();
	}