<?php
	header("content-type:text/html;charset=utf-8");
	//重写

	class A{
		
		public function getSum(array $n1, array $n2){
			
			echo '<br> 求出两个数组的和';
		}
	}

	class B extends A{
		public function getSum($n1, $n2){
			
			echo '<br> 求出两个数和';
		}
	}



