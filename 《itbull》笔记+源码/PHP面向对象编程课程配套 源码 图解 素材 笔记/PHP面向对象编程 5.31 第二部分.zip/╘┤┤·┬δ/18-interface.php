<?php
	header("content-type:text/html;charset=utf-8");
	
	interface iAbc{
		//接口中可以有常量
		const TAX_RATE = 0.08;
		//接口不可以包含成员属性(静态和非静态都不可以)
		//public $name = 'hello';

		public function sayHello();

	}

	echo iAbc::TAX_RATE;

	
