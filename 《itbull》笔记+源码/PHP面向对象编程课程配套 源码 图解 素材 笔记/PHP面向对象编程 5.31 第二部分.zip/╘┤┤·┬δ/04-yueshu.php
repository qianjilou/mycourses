<?php
	header("content-type:text/html;charset=utf-8");
	//类型约束说明

	class Dog{
	}

	class Cat{}

	function test(Dog $dog, array $arr, callable $f, array $arr1 = null ){

		echo '<pre>';
		var_dump($dog);
		var_dump($arr);

		$f();

	}

	test(new Dog(), array(1, 9), function (){ echo 'sayhello';}, null);