<?php
	header("content-type:text/html;charset=utf-8");
	//属性的重载

	class Dog{
		
		public $age = 10;
		//私有的数组，管理我们的重载的属性
		private $pro_array = array();

		//写一个方法，来管理动态增长的属性
		function __set($pro_name, $val){

			$this->pro_array[$pro_name] = $val;
		}

		//写一个方法，来返回你动态的属性
		function __get($pro_name){
			//echo '__get' . $pro_name;
			if(isset($this->pro_array[$pro_name])){
				return $this->pro_array[$pro_name];
			}else{
				return '<br>属性不存在';
			}
		}

	}

	$dog1 = new Dog();
	$dog1->name = '哮天犬';

	echo $dog1->name;
	//echo $dog1->age;
