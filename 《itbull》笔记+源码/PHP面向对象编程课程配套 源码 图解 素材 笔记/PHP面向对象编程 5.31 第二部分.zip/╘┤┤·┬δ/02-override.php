<?php
	header("content-type:text/html;charset=utf-8");
	//重写问题的引入

	class Animal{
		
		public $name = '动物';
		public static $total_num = 10;

		//动物都会叫
		//父类的方法，在某些情况下，不能确定
		//则该方法，就可能被子类覆盖(重写)
		public function cry(){
			echo '<br> 动物叫，这里不知道怎么叫..';
		}
	}
	class Cat extends Animal{
		//这里我们的子类的cry 就重写了(覆盖)父类的cry
		public function cry(){
			echo '小猫喵喵叫...';
			//这里我们可以去调用父类的被重写的方法
//			Animal::cry();
			parent::cry();
			
			//我们希望访问到父类的static $total_num
			//要求 $total_num 是public 或者 protected
			echo '<br> Animal $total_num' . parent::$total_num;

		}
	}

	$cat1 = new Cat();
	$cat1->cry();
	