<?php
	header("content-type:text/html;charset=utf-8");
	//抽象类最佳实践

	abstract class DB{
		
		public $conn;

		//定义两个抽象方法
		abstract function getConnect(array $arr = null);
		abstract function query(array $arr = null);
	}

	//小红
	class MySQLDB extends DB{
		function getConnect(array $arr = null){
			echo '<br>得到一个mysql的连接';
		}
		function query(array $arr = null){
			echo '<br> 查询mysql';
		}
	}

	class OracleDB extends DB{
		function getConnect(array $arr = null){
			echo '<br>得到一个oracle的连接';
		}
		function query(array $arr = null){
			echo '<br> 查询oracle';
		}
	}

	$mysqldb = new MySQLDB;
	$mysqldb->getConnect(array('host'=>'localhost'));
	$mysqldb->query(array('sql'=>'select * from users'));