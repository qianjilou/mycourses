<?php
	header("content-type:text/html;charset=utf-8");
	class A{
		public $name = 'hello';
		private $salary = 90;
		public function  getVal(){
			return $this->salary;
		}
	}

	class B extends A{
		
		///使用到 $salary;
		public function abc(){
			
			echo $this->getVal();
			 
		}
		
	}

	$b = new B();
	$b->abc();