<?php
	header("content-type:text/html;charset=utf-8");
	//多态
	class Animal{
		
		public $name;
		public function __construct($name){
			$this->name = $name;
		}
	}

	//狗狗
	class Dog extends Animal{
		
		public function showInfo(){
			
			echo $this->name;
		}
	}

	class Cat extends Animal{
		
		public function showInfo(){
			
			echo $this->name;
		}
	}


	class Food{
		public $name;

		public function __construct($name){
			$this->name = $name;
		}
	}

	class Fish extends Food{

		public function showInfo(){
			echo $this->name;
		}
	}
	class Bone extends Food{

		public function showInfo(){
			echo $this->name;
		}
	}

	$dog = new Dog('德国黑背');
	$cat = new Cat('波斯猫');

	$fish = new Fish('鲤鱼');
	$bone = new Bone('大棒骨');

	class Master{
		
		public $name;

		public function __construct($name){
			$this->name = $name;
		}

		//喂食
		public function feed(Animal $animal, Food $food){
			echo '<br>';
			$animal->showInfo();
			echo '喜欢吃';
			$food->showInfo();
		}

	}

	//创建一个主人
	$master = new Master('小红');
	$master->feed($dog, $bone);
	$master->feed($cat, $fish);
	