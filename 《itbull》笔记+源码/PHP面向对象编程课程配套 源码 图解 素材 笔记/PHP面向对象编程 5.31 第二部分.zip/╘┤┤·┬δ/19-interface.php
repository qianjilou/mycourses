<?php
	header("content-type:text/html;charset=utf-8");
	//一个接口不能继承其它的类,但是可以继承别的接口

	interface iAbc{
		public function sayOk();
	}
	
	interface iMyInterface{

		public function getSum($n1, $n2);
	}

	interface iUsb extends iAbc,iMyInterface{
		public function sayHello();
	}

	class A implements iUsb{
		
		public function sayOk(){
		}
		public function getSum($n1, $n2){
		}
		public function sayHello(){
		}
	}	

