<?php
	header("content-type:text/html;charset=utf-8");
	//接口的使用入门

	//命名规范  ， 以 i开后，后面使用驼峰法来编写
	//特点 1. 关键字 interface 2. 接口中的方法没有方法体
	//接口的价值在于设计，他让其他的类来实现它声明的方法
	interface iMyInterface{

		/**
		@功能： 计算两个数的和 【效率】
		@$n1: 是数，要求校验...
		@return : 返回结果(保留两位小数)
		*/
		public function getSum($n1, $n2);

	}

	class Monkey implements  iMyInterface{
		//这里，我们实现 iMyInterface 声明的方法
		public function getSum($n1, $n2){
			return $n1 + $n2;
		}
	}

	$monkey = new Monkey;
	echo $monkey->getSum(10, 30);

