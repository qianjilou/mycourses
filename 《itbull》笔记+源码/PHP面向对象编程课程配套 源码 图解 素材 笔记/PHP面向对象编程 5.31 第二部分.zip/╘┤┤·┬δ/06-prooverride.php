<?php
	header("content-type:text/html;charset=utf-8");
	//属性重写

	class Person{
		
		public $name = '小黄';
		protected $age = 90;
		private $salary = 789;
	}

	class Student extends Person{

		public $name = '小马';
		protected $age = 9;
		private $salary = 78;

		public function showInfo(){
			
			echo '<br>' . $this->name . ' age' . $this->age . ' salary=' .$this->salary;
		}
		
	}

	$student = new Student;
	echo '<br>'  . $student -> name;

	echo $student->showInfo();