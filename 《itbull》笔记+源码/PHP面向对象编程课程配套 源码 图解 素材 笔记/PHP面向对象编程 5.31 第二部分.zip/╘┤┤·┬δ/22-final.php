<?php
	header("content-type:text/html;charset=utf-8");
	//说明final 的注意事项

	class SuperMan{
		
		final  public  $name;
		public $ability;

		//不让子类重写我们的attact方法
		public function attact(){
			echo '<br>超人的攻击方式: 原子弹...';
		}
	}

	$superMan = new SuperMan;
	$superMan->attact();