<?php
	header("content-type:text/html;charset=utf-8");
	/*
	要求:
	请编写一个和尚类Monk ，这个和尚很猛，可以完成如下人
	属性(名字, 年龄，本领，性别)
	可以通过如下方式来完成如下做如下功能
      $monk1->play($arr); => 传入一个数组，可以对数组进行排序，要求对传入的数组本身排序. [提示 信息为 xx和尚 完成了 xx任务]
      $monk1->play($arr1, $arr2) => 传入两个数组，可以将数组合并后，返回新数组     [提示 信息为 xx和尚 完成了 xx任务]
      $monk1->play($arr1, $num) => 输入一个数组，和一个数，可以查询$arr1中有没有这个数，并返回该数在$arr1 的下标，如果查不到，
	就返回-1 。 [提示 信息为 xx和尚 完成了 xx任务]

	*/

	class Monk{
		public $name;
		public $age;
		public $ability;
		protected $sex;

		private function mySort($arr){
			$arr = null;
			echo '<br> 和尚排序...';
			return $arr;
		}

		private function arrMerge($arr1, $arr2){
			echo '<br> 和尚合并...';
		}
		private function arrSearch($arr1, $val){
			echo '<br> 和尚查找...' ;
		}

		//魔术方法
		public function __call($method, $args){
			
			if($method == 'play'){
				
				if(count($args) == 1){
					$this->mySort($args[0]);
				}else if(count($args) == 2){
					//判断数据的类型
					if(is_array($args[0]) && is_array($args[1])){
						$this->arrMerge($args[0], $args[1]);
					}else if(is_array($args[0]) && is_numeric($args[1])){

						$this->arrSearch($args[0], $args[1]);
						
					}
				}

			}else{
				echo '调用错误';
			}
		}
		

	}

	$arr = array(40, 80, 0);
	$arr2 = array(40, 80, 10);
	$monk = new Monk();
	$arr = $monk->play($arr);

	$arr = array(40, 80, 0);
	$arr2 = array(40, 80, 10);

	$monk->play($arr, $arr2);

	$monk->play($arr, 10);

	echo '<pre>';
	var_dump($arr);

