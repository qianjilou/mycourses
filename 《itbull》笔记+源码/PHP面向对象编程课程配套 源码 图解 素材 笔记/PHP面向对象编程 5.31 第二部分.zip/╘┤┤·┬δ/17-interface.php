<?php
	header("content-type:text/html;charset=utf-8");
	
	interface iAbc{
		
		public function sayHello();
		//接口中不可以有 实现的方法,方法不能有方法体.
//		public function getVal(){
//			
//		}
	}
	interface iUsb{
		public function start();
	}

	//一个类，可以同时实现多个接口，则需要把所有接口的方法都实现了
	class A implements iAbc, iUsb{
		public function sayHello(){
			echo '<br> sayHello()';
		}
		public function start(){
			echo '<br> start()';
		}
	}