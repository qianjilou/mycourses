<?php
	header("content-type:text/html;charset=utf-8");
	//练习
//	class Animal{
//		public function cry(){
//			echo '动物叫唤..';
//		}
//	}
//	class Cat extends Animal{
//		public function cry($name){
//			echo '猫猫叫唤..';
//		}
//		public function cry(){
//		}
//	}
//	$cat1=new Cat();
//	$cat1->cry("abc");

//	class Animal{
//		public function cry($val){
//		echo '动物叫唤..';
//		}
//	}
//	class Cat extends Animal{
//		public  function cry($name){
//			echo '猫猫叫唤..';
//		}
//	}
//	$cat1=new Cat();
//	$cat1->cry("abc");

//	class Animal{
//		public function cry($val){
//			echo '动物叫唤..';
//		}
//	}
//	class Cat extends Animal{
//		protected  function cry($name){
//			echo '猫猫叫唤..';
//		}
//	}
//	$cat1=new Cat(); 
//	$cat1->cry('ok');
class Animal{
protected function cry($val){
	echo '动物叫唤..';
}}
class Cat extends Animal{
public  function cry($name){
	echo '猫猫叫唤..';
}}
$cat1=new Cat(); $cat1->cry(array(1,9));



