<?php
	header("content-type:text/html;charset=utf-8");
	//模拟电脑插入外部设备工作

	interface iUsb{
		//开始工作
		public function start();
		//停止工作
		public function stop();
	}

	//手机来实现接口的方法
	class Phone implements iUsb{
		public function start(){
			echo '<br> 手机开始工作 ....';
		}
		public function stop(){
			echo '<br> 手机停止工作 ....';
		}
	}
	//相机来实现接口的方法
	class Camera implements iUsb{
		public function start(){
			echo '<br> 相机开始工作 ....';
		}
		public function stop(){
			echo '<br> 相机停止工作 ....';
		}
	}

	//写计算机类
	class Computer {
		
		public function work($iUsb){
			$iUsb->start();
			echo '<br>工作了10个小时...';
			$iUsb->stop();
		}
	}

	//创建手机对象
	$phone = new Phone();
	$camera = new Camera();
	//创建一个computer对象
	$computer = new Computer();
	$computer->work($phone);
	$computer->work($camera);