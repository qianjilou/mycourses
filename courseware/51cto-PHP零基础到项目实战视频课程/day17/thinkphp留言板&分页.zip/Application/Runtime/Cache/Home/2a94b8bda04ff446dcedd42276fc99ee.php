<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>首页</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="/php0314/tp/Public/css/bootstrap.css"/>
        <script src="/php0314/tp/Public/js/jquery.js"></script>
        <script src="/php0314/tp/Public/js/bootstrap.js"></script>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <form action="/php0314/tp/index.php/Home/Index/insert" method="post" class="form-horizontal">
                    <div class="form-group">
                        <label class="col-md-2 control-label">标题:</label>
                        <div class="col-md-6">
                            <input type="text" class="form-control" name="title" />
                        </div>
                    </div>
                    <div class="form-group">                        
                        <div class="col-md-offset-2 col-md-10">
                            <textarea name="content" rows="10" class="form-control"></textarea>
                        </div>
                    </div>
                    <div class="form-group">                        
                        <div class="col-md-offset-2 col-md-10">
                            <input type="submit" name="publish" value="发布" class="btn btn-primary"/>
                        </div>
                    </div>
                </form>
            </div>            
            <div class="clearfix"></div>
            <div class="row col-md-offset-2">                
                <?php echo ($page); ?>                
            </div>
            <div class="clearfix"></div>
            <div class="row col-md-offset-2">
                <?php if(is_array($msgList)): $i = 0; $__LIST__ = $msgList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><div class="media">               
                    <div class="media-body">
                        <h4 class="media-heading"><a href="javascript:;"><?php echo ($vo["message_id"]); ?>,<?php echo ($vo["title"]); ?></a></h4>
                        <?php echo ($vo["content"]); ?>
                    </div>
                </div><?php endforeach; endif; else: echo "" ;endif; ?>
            </div>
        </div>
    </body>
</html>