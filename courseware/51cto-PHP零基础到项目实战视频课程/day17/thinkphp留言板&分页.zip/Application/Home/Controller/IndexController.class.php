<?php
namespace Home\Controller;
use Think\Controller;
class IndexController extends Controller {
    public function index(){
//        $this->show('<style type="text/css">*{ padding: 0; margin: 0; } div{ padding: 4px 48px;} body{ background: #fff; font-family: "微软雅黑"; color: #333;font-size:24px} h1{ font-size: 100px; font-weight: normal; margin-bottom: 12px; } p{ line-height: 1.8em; font-size: 36px } a,a:hover{color:blue;}</style><div style="padding: 24px 48px;"> <h1>:)</h1><p>欢迎使用 <b>ThinkPHP</b>！</p><br/>版本 V{$Think.version}</div><script type="text/javascript" src="http://ad.topthink.com/Public/static/client.js"></script><thinkad id="ad_55e75dfae343f5a1"></thinkad><script type="text/javascript" src="http://tajs.qq.com/stats?sId=9347272" charset="UTF-8"></script>','utf-8');
        
        
        $msgModel = new \Think\Model( "message" );
        
        $count      = $msgModel->count();// 查询满足要求的总记录数
        $Page       = new \Think\Page($count,1);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出
        // 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $msgList = $msgModel->order('message_id DESC')->limit($Page->firstRow . ',' . $Page->listRows)->select();
        
//        $this->assign('list',$msgList);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        
//        $msgList = $msgModel->order("message_id DESC")->select();
//          $msgList = $msgModel->where("message_id=2")->select();
//        $msgList = $msgModel->find(2);
//        print_r( $msgList );
//        $this->display( "Index/index" );
        
        $this->assign( "msgList", $msgList );
        
        $this->display();
//        $this->display( "test" );
    }
    
    public function insert () {
//        $title = I("post.title");
//        $content = I("post.content");
//        $msgInfo = array(
//            "title" => $title,
//            "content" => $content,
//        );
//        $msgModel = new \Think\Model( "message" );
        $msgModel = M( "message" );
        $msgInfo = $msgModel->create();
        if ( $msgModel->add( $msgInfo ) ) {
            $this->success( "留言发布成功" );
        }else {
            $this->error( "留言发布失败" );
        }
    }
    
    public function test() {
//        echo "Home::Index::test Method";
        $this->display();
    }
    
    protected function test2 () {
        echo "Home::Index::test2 Method";
    }
    
    private function test3 () {
        echo "Home::Index::test3 Method";
    }
    
    
}