<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>首页</title>
	<link rel="stylesheet" href="./css/bootstrap.css">
	<script src="../js/jquery.js"></script>
	<script src="../js/bootstrap.js"></script>
</head>
<body>
	
	<div class="container">
		<div class="row">
			<?php include( "header.php" ); ?>	
		</div>
		<?php		
			$total = $mysql->getCol( "SELECT COUNT(*) as total FROM message" );
			$pageSize = 5;
			$page = ceil( $total / $pageSize );
			$p = isset( $_GET['p'] ) ? intval( $_GET['p']) : 1;
			$sql = "SELECT * FROM message ORDER BY message_id ASC LIMIT " . ( $p - 1 ) * $pageSize . "," . $pageSize;
			$msgList = $mysql->getAll( $sql );

			$slideModel = new SlideModel( $mysql );
			$slideList = $slideModel->getSlideList();
			$slideNums = count( $slideList );
		?>
		<div class="row">
			<div class="carousel slide" id="slide" data-ride="carousel" data-interval="2000" data-wrap="true">
				<ol class="carousel-indicators">
				<?php
					for ( $i = 0; $i < $slideNums; $i++ ) {
					?>
					<li data-target="#slide" data-slide-to="<?php echo $i; ?>" class="<?php echo $i == 0 ? 'active' : ''; ?>" ></li>
					<?php						
					}
				?>
				</ol>
				<div class="carousel-inner">
					<?php
					if ( !empty( $slideList ) ) {
						foreach( $slideList as $k => $v ) {
							?>
							<div class="item <?php echo $k == 0 ? "active" : ""; ?>">
								<img src="./upload/<?php echo $v['img']; ?>" alt="" width="1170">
							</div>
							<?php
						}
					}
					?>
				</div>
				<a class="carousel-control left" href="#slide" data-slide="prev">
				<span class="glyphicon glyphicon-chevron-left" ></span>
					<span class="sr-only">&lsaquo;</span>
				</a>
				<a class="carousel-control right" href="#slide" data-slide="next">
				<span class="glyphicon glyphicon-chevron-right" ></span>
					<span class="sr-only">&lsaquo;</span>
				</a>
			</div>			
		</div>

		<div class="row">
			<ul class="pagination">
				<li><a href="?p=1">首页</a></li>
				<?php
					if ( $p == 1 ){
					?>
					<li class="disabled"><a href="javascript:;">上一页</a></li>
					<?php						
					}else {
						?>
							<li><a href="?p=<?php echo $p - 1; ?>">上一页</a></li>
						<?php	
					}
				?>	
				<?php
					$active = '';
					for ( $i = 1; $i <= $page; $i++ ) {
						if ( $p == $i ) {
							$active = "active";
						}else {
							$active = "";
						}
						?>
							<li class="<?php echo $active; ?>"><a href="?p=<?php echo $i;?>"><?php echo $i;?></a></li>
						<?Php
					}
				?>
				<?php
					if ( $p == $page ){
					?>
					<li class="disabled"><a href="javascript:;">下一页</a></li>
					<?php						
					}else {
						?>
							<li><a href="?p=<?php echo $p + 1; ?>">下一页</a></li>
						<?php	
					}
				?>	
				<li><a href="?p=<?php echo $page; ?>">尾页</a></li>
			</ul>
			<?php			
				if ( !empty( $msgList ) ) {
					foreach ( $msgList as $k => $v ) {
						?>
						<div class="media">
							<div class="pull-left">
								<img width="200" height="150" src="./upload/<?php echo !empty($v['img']) ? $v['img'] : 'nopic.jpg'; ?>" alt="" class="media-object" >
							</div>
							<div class="media-body">
								<h3><?php echo $v['message_id']; ?>,<a href="detail.php?id=<?php echo $v['message_id']; ?>"><?php echo $v['title']; ?></a></h3>
								<p><?php echo mb_substr( htmlspecialchars_decode($v['content']), 0, 360, "utf-8" ) . "..."; ?></p>
							</div>
						</div>
						<?php
					}
				}
			?>	
		</div>
	</div>
</body>
</html>