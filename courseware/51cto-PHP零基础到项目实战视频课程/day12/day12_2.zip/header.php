<div class="navbar navbar-inverse">
	<div class="navbar-header">
		<a href="#" class="navbar-brand">信息管理系统</a>
	</div>
	<?php
		require( "Mysql.class.php" );	
		require( "CatModel.class.php" );	
		require( "SlideModel.class.php" );

		$catModel = new CatModel( $mysql );
		$catList = $catModel->getCatList();
		$catId = !empty( $_REQUEST['id'] ) ? intval( $_REQUEST['id'] ) : 0;
		$active = "";
		if ( $catId == 0 ) {
			$active = "active";
		}
	?>
	<ul class="nav navbar-nav">
		<li class="<?php echo $active; ?>" ><a href="./">首页</a></li>
		<?php
			
			if ( !empty( $catList ) ) {
				foreach( $catList as $k => $v ) {
					if ( $catId == $v['cat_id'] ) {
						$active = "active";
					}else {
						$active = "";
					}
					?>
					<li class="<?php echo $active; ?>"><a href="cat.php?id=<?php echo $v['cat_id'] ?>"><?php echo $v['cat_name'];?></a></li>
					<?php
				}
			}
		?>
	</ul>
</div>	