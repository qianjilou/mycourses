<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>留言板</title>
	<link rel="stylesheet" href="../css/bootstrap.css">
	<style>
	body {
		padding: 20px;
	}
	</style>
	<link rel="stylesheet" href="./plugin/kindeditor/plugins/code/prettify.css" />
    <script charset="utf-8" src="./plugin/kindeditor/kindeditor.js"></script>
    <script charset="utf-8" src="./plugin/kindeditor/lang/zh_CN.js"></script>
    <script charset="utf-8" src="./plugin/kindeditor/plugins/code/prettify.js"></script>
    <script>
        KindEditor.ready(function(K) {
            var editor1 = K.create('textarea[name="content"]', {
                cssPath: './plugin/kindeditor/plugins/code/prettify.css',
                uploadJson: './plugin/kindeditor/php/upload_json.php',
                fileManagerJson: './plugin/kindeditor/php/file_manager_json.php',
                allowFileManager: true,
                afterCreate: function() {
                    var self = this;
                    K.ctrl(document, 13, function() {
                        self.sync();
                        K('form[name=article_add]')[0].submit();
                    });
                    K.ctrl(self.edit.doc, 13, function() {
                        self.sync();
                        K('form[name=article_add]')[0].submit();
                    });
                }
            });
            prettyPrint();
        });
    </script>
</head>
<body>
<?php
	require( "Mysql.class.php" );
	require( "lib.php" );
?>

<?php
	$msgInfo = array();
	$act = "";
	$tipInfo = "";
	if ( isset( $_REQUEST['act'] ) && $_REQUEST['act'] == 'add' ) {
		$act = "insert";
		$tipInfo = "添加留言";
	}else if ( isset( $_REQUEST['act'] ) && $_REQUEST['act'] == 'insert'
	|| isset( $_REQUEST['act'] ) && $_REQUEST['act'] == 'update' ) {
		$title = htmlspecialchars( $_POST['title'], ENT_QUOTES );
		$content = htmlspecialchars( $_POST['content'], ENT_QUOTES);
		$catId = $_POST['cat_id'];
		$uploadFile = upload();
		$msgInfo = array(
			"title" => $title,
			"content" => $content,
			"cat_id" => $catId,
		);
		if ( $uploadFile ) { 
			$msgInfo['img'] = $uploadFile;
		}
		if ( $_REQUEST['act'] == 'insert' ) {
			$tipInfo = "添加留言";
			$bRes = $mysql->add( "message", $msgInfo );
			$act = 'insert';
		}else {
			$id = $_REQUEST['id'];
			$tipInfo = "编辑留言";
			$msgInfo['message_id'] = $id;
			$bRes = $mysql->update( "message", $msgInfo, "WHERE message_id = " . $id );
			$act = 'update';
		}
		if ( $bRes ) {
			?>
			<script>
			alert( "ok" );
			</script>
			<?Php
		}else {
			?>
			<script>
			alert( "error" );
			</script>
			<?php
		}
	}else if ( isset( $_REQUEST['act'] ) && $_REQUEST['act'] == 'edit' ) {
		if ( !empty( $_REQUEST['id'] ) ) {
			$msgInfo = $mysql->getRow( "SELECT * FROM message WHERE message_id = " . $_REQUEST['id'] );
		}
		$tipInfo = "更新留言";
		$act = 'update';
	}
	$sqlList = "SELECT * FROM category";
	$msgList = $mysql->getAll( $sqlList );
?>

	<div class="container">
		<?php include( "header.php" ); ?>
		<div class="row">
			<form action="" method="post" class="form-horizontal" enctype="multipart/form-data">
				<div class="form-group">
					<label for="" class="control-label col-md-2">
					主题:
					</label>					
					<div class="col-md-10">
						<input type="text" name="title" id="title" class="form-control" value="<?php if ( !empty( $msgInfo['title'] ) ) {
							echo $msgInfo['title'];
							}?>">
					</div>
				</div>
				<div class="form-group">
					<label for="" class="control-label col-md-2">
						分类列表:	
					</label>
					<div class="col-md-10">
						<select name="cat_id" id="" class="form-control" >
							<option value="0">请选择分类</option>	
							<?php
								if ( !empty( $msgList ) ) {
									foreach( $msgList as $k => $v ){
										?>
										<option value="<?php echo $v['cat_id']; ?>" <?php if( $v['cat_id'] == $msgInfo['cat_id'] ){
											echo "selected";
											} ?> ><?php echo $v['cat_name']; ?></option>
										<?php
									}
								}
							?>
						</select>	
					</div>
				</div>
				<div class="form-group">
					<label for="" class="control-label col-md-2">
						上传图片:
					</label>	
					<div class="col-md-10">
						<input type="file" name="photo" id="photo">
					</div>
				</div>
				<div class="form-group">
					<div class="col-md-offset-2 col-md-10">
						<textarea class="form-control" name="content" id="content" cols="30" rows="10"><?php if ( !empty( $msgInfo['content'] ) ) {
							echo $msgInfo['content'];
							} ?></textarea>	
					</div>
				</div>
				<div class="form-group">
					<div class="col-md-offset-2 col-md-10">
						<input type="submit" name="submit" value="<?php echo $tipInfo; ?>" class="btn btn-primary"> 	
					</div>
				</div>
				<input type="hidden" name="act" value="<?php echo $act; ?>">
				<input type="hidden" name="id" value="<?php if ( !empty( $msgInfo['message_id']) ){
					echo $msgInfo['message_id'];
					} ?>">
			</form>
		</div>
		
	</div>


</body>
</html>