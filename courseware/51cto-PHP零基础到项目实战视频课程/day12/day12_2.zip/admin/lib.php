<?php
	
	function upload () {
		if ( isset( $_POST['submit'] ) ) {
			$uploadDir = "../upload/";
			$ext = array( "jpg", "gif", "png", "jpeg", "bmp" );
			$fileInfo = explode( ".", $_FILES['photo']['name'] );
			$fileExt = array_pop( $fileInfo );
			if ( !in_array( $fileExt, $ext ) ) {
				return false;
			}
			if ( !is_dir( $uploadDir ) ) {
				mkdir( $uploadDir );
			}
			$fileName = $uploadDir . $_FILES['photo']['name'];
			if ( move_uploaded_file( $_FILES['photo']['tmp_name'], $fileName ) ) {
				return $_FILES['photo']['name'];
			}else {
				return false;
			}
		}
	}

	

?>