<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>添加/编辑分类页面</title>
	<link rel="stylesheet" href="../css/bootstrap.css">
</head>
<body>
<?php
	require( "Mysql.class.php" );
	require( "CatModel.class.php" );
	require( "lib.php" );
?>

<?php
	$catInfo = array();
	$act = "";
	$tipInfo = "";
	if ( isset( $_REQUEST['act'] ) && $_REQUEST['act'] == 'add' ) {
		$act = "insert";
		$tipInfo = "添加分类";
	}else if ( isset( $_REQUEST['act'] ) && $_REQUEST['act'] == 'insert'
	|| isset( $_REQUEST['act'] ) && $_REQUEST['act'] == 'update' ) {
		$pid = htmlspecialchars( $_POST['pid'], ENT_QUOTES );
		$catName = htmlspecialchars( $_POST['cat_name'], ENT_QUOTES);
		$catInfo = array(
			"pid" => $pid,
			"cat_name" => $catName,
		);
		if ( $_REQUEST['act'] == 'insert' ) {
			$tipInfo = "添加分类";
			$bRes = $mysql->add( "category", $catInfo );
			$act = 'insert';
		}else {
			$id = $_REQUEST['id'];
			$tipInfo = "编辑分类";
			$catInfo['cat_id'] = $id;
			$bRes = $mysql->update( "category", $catInfo, "WHERE cat_id = " . $id );
			$act = 'update';
		}
		if ( $bRes ) {
			?>
			<script>
			alert( "ok" );
			</script>
			<?Php
		}else {
			?>
			<script>
			alert( "error" );
			</script>
			<?php
		}
	}else if ( isset( $_REQUEST['act'] ) && $_REQUEST['act'] == 'edit' ) {
		if ( !empty( $_REQUEST['id'] ) ) {
			$catInfo = $mysql->getRow( "SELECT * FROM category WHERE cat_id = " . $_REQUEST['id'] );
		}
		$tipInfo = "更新分类";
		$act = 'update';
	}
	// print_r( $catInfo );
	$sqlList = "SELECT * FROM category";
	$msgList = $mysql->getAll( $sqlList );
?>
	<div class="container">
		<?php
			include( "header.php" );
		?>
		<div class="row">
			<form action="" method="post" class="form-horizontal">
				<div class="form-group">
					<label for="" class="control-label col-md-2">
						分类列表:	
					</label>
					<div class="col-md-10">
						<select name="pid" id="" class="form-control" >
							<option value="0">请选择分类</option>	
							<?php
								if ( !empty( $msgList ) ) {
									foreach( $msgList as $k => $v ){
										?>
										<option value="<?php echo $v['pid']; ?>"><?php echo $v['cat_name']; ?></option>
										<?php
									}
								}
							?>
						</select>	
					</div>
				</div>
				<div class="form-group">
					<label for="" class="control-label col-md-2">分类名称:</label>
					<div class="col-md-10">
						<input class="form-control" type="text" name="cat_name" value="<?php if( !empty($catInfo['cat_name']) ){
								echo $catInfo['cat_name'];
							} ?>">
					</div>
				</div>
				<div class="form-group">
					<div class="col-md-offset-2 col-md-10">
						<input class="btn btn-primary" type="submit" value="添加分类" name="submit">
					</div>
				</div>
				<input type="hidden" name="act" value="<?php echo $act; ?>">
				<input type="hidden" name="id" value="<?php if( !empty($catInfo['cat_id']) ){
								echo $catInfo['cat_id'];
							} ?>">
			</form>
		</div>		
	</div>		
</body>
</html>