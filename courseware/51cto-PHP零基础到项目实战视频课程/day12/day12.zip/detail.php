<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>文章详情页</title>
	<link rel="stylesheet" href="./css/bootstrap.css">
</head>
<body>
	<?php
		require( "Mysql.class.php" );
	?>
	<?php
		$id = !empty( $_REQUEST['id'] ) ? $_REQUEST['id'] : 0;
		if ( !empty( $id ) ) {
			$msgInfo = $mysql->getRow( "SELECT * FROM message WHERE message_id = " . $id );
		}else {
			header( "index.php" );
		}
	?>	
	<div class="container">
		<div class="row">
			<?php
				if ( !empty( $msgInfo ) ) {
					?>
					<h3 class="text-center"><?php echo $msgInfo['title']; ?></h3>
					<div class="col-md-12">
						<?php echo htmlspecialchars_decode( $msgInfo['content'] ); ?>
					</div>
					<?php
				}
			?>
		</div>
	</div>
</body>
</html>