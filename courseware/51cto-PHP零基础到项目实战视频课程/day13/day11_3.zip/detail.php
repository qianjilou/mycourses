<?php
	require( "init.php" );
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>文章详情页</title>
	<link rel="stylesheet" href="./css/bootstrap.css">
</head>
<body>
	
	<div class="container">
		<div class="row">
			<?php include( "header.php" ); ?>
		</div>
		<div class="row">
			<?php include ( "ur_here.php" ); ?>
		</div>
		<?php
			$arcId = !empty( $_REQUEST['arcId'] ) ? $_REQUEST['arcId'] : 0;
			if ( !empty( $arcId ) ) {
				$msgInfo = $mysql->getRow( "SELECT * FROM message WHERE message_id = " . $arcId );
			}else {
				echo "<script>location.href='index.php'</script>";
			}
		?>	
		<div class="row">
			<?php
				if ( !empty( $msgInfo ) ) {
					?>
					<h3 class="text-center"><?php echo $msgInfo['title']; ?></h3>
					<div class="col-md-12">
						<?php echo htmlspecialchars_decode( $msgInfo['content'] ); ?>
					</div>
					<?php
				}
			?>
		</div>
		<div style="height:20px;"></div>
		<div class="row">
			<form action="" class="form-horizontal" method="post">
				<div class="form-group">
					<div class="col-md-12">
						<textarea name="content" id="" cols="30" rows="10" class="form-control"></textarea>
					</div>
				</div>
				<div class="form-group">
					<div class="col-md-12">
						<input type="submit" value="发布留言" name="publish" class="btn btn-primary">
					</div>					
				</div>
			</form>
		</div>
	</div>
	
	<?php
		if ( isset( $_POST['publish'] ) ) {
			if ( empty( $_SESSION['userName'] ) ) {
				echo "<script>location.href='user.php';</script>";
				exit();
			}else if ( !empty( $_SESSION['userName'] ) ) {
				$sql = "SELECT * FROM member WHERE user_name = '{$_SESSION['userName']}' AND user_password = '{$_SESSION['userPwd']}'";
				if ( !$mysql->getRow( $sql ) ) {
					echo "<script>location.href='user.php';</script>";
					exit();
				}
			}
			$content = htmlspecialchars( $_POST['content'], ENT_QUOTES);
			if ( !empty( $content ) ) {
				$data = array(
					"content" => $content,
					"is_show" => 0,
					"sort" => 0,
					"publish_time" => date( "Y-m-d H:i:s" ),
					"message_id" => $_REQUEST['arcId'],
					"user_id" => $_SESSION['user_id'],
				);
				if ( $mysql->add( "comment", $data ) ) {
					echo "<script>alert('ok');</script>";
				}else {
					echo "<script>alert('error');</script>";
				}
			}
		}

	?>

	<div class="container">
		<?php
			$total = $mysql->getCol( "SELECT COUNT(*) as total FROM comment WHERE message_id = " . $_REQUEST['arcId'] );

			$pageSize = 5;
			$page = ceil( $total / $pageSize );
			$p = isset( $_GET['p'] ) ? intval( $_GET['p']) : 1;
			$sql = "SELECT * FROM comment WHERE message_id = {$_REQUEST['arcId']} ORDER BY comment_id ASC LIMIT " . ( $p - 1 ) * $pageSize . "," . $pageSize;
			$commentList = $mysql->getAll( $sql );
		?>
	<div class="row">
		<ul class="pagination">
			<li><a href="?id=<?php echo $catId; ?>&arcId=<?php echo $arcId; ?>&p=1">首页</a></li>
			<?php
				if ( $p == 1 ){
				?>
				<li class="disabled"><a href="javascript:;">上一页</a></li>
				<?php						
				}else {
					?>
						<li><a href="?id=<?php echo $catId; ?>&arcId=<?php echo $arcId; ?>&p=<?php echo $p - 1; ?>">上一页</a></li>
					<?php	
				}
			?>	
			<?php
				$active = '';
				for ( $i = 1; $i <= $page; $i++ ) {
					if ( $p == $i ) {
						$active = "active";
					}else {
						$active = "";
					}
					?>
						<li class="<?php echo $active; ?>"><a href="?id=<?php echo $catId; ?>&arcId=<?php echo $arcId; ?>&p=<?php echo $i;?>"><?php echo $i;?></a></li>
					<?Php
				}
			?>
			<?php
				if ( $p == $page ){
				?>
				<li class="disabled"><a href="javascript:;">下一页</a></li>
				<?php						
				}else {
					?>
						<li><a href="?id=<?php echo $catId; ?>&arcId=<?php echo $arcId; ?>&p=<?php echo $p + 1; ?>">下一页</a></li>
					<?php	
				}
			?>	
			<li><a href="?id=<?php echo $catId; ?>&arcId=<?php echo $arcId; ?>&p=<?php echo $page; ?>">尾页</a></li>
		</ul>
		<?php			
			if ( !empty( $commentList ) ) {
				foreach ( $commentList as $k => $v ) {
					?>
					<div class="media">
						<div class="media-body">
							<p><?php echo mb_substr( htmlspecialchars_decode($v['content']), 0, 360, "utf-8" ) . "..."; ?></p>
						</div>
					</div>
					<?php
				}
			}
		?>	
	</div>
	</div>


</body>
</html>