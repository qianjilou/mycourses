<?php
	class SlideModel extends Mysql {
		public $tbName = "slide";
		public $db;
		public function __construct ( &$objDb ) {
			$this->db = $objDb;
		}

		public function addSlide ( $data ) {
			return $this->db->add( $this->tbName, $data );
		}

		public function updateSlide ( $data, $condition ) {
			return $this->db->update( $this->tbName, $data, $condition );
		}

		public function getSlideList () {
			return $this->db->getAll( "SELECT * FROM {$this->tbName}" );
		}

		public function getSlideInfo ( $SlideId ) {
			return $this->db->getRow( "SELECT * FROM {$this->tbName} WHERE slide_id = " . $SlideId );
		}

		public function delSlide( $SlideId ) {
			return $this->db->query( "DELETE FROM {$this->tbName} WHERE slide_id = " . $SlideId );
		}
	}

?>