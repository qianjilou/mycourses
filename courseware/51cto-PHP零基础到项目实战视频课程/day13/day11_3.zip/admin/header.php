<div class="navbar navbar-inverse">
	<div class="navbar-header">
		<a href="#" class="navbar-brand">信息管理系统</a>
	</div>
	<?php
		$scriptName = $_SERVER['SCRIPT_FILENAME'];
	?>
	<ul class="nav navbar-nav">
		<li class="<?php if ( preg_match( '/message/', $scriptName ) ) {
			echo "active";
			} ?>"><a href="message_list.php">信息列表</a></li>
		<li class="<?php if ( preg_match( '/category/', $scriptName ) ) {
			echo "active";
			} ?>"><a href="category.php">分类管理</a></li>
		<li class="<?php if ( preg_match( '/slide/', $scriptName ) ) {
		echo "active";
		} ?>"><a href="slide.php">轮播管理</a></li>
	</ul>
	</ul>
</div>	