<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>图片板</title>
	<link rel="stylesheet" href="../css/bootstrap.css">
</head>
<body>
<?php
	require( "Mysql.class.php" );
	require( "SlideModel.class.php" );
	require( "lib.php" );
	$slideModel = new SlideModel( $mysql );
?>

<?php
	$slideInfo = array();
	$act = "";
	$tipInfo = "";
	if ( isset( $_REQUEST['act'] ) && $_REQUEST['act'] == 'add' ) {
		$act = "insert";
		$tipInfo = "添加图片";
	}else if ( isset( $_REQUEST['act'] ) && $_REQUEST['act'] == 'insert'
	|| isset( $_REQUEST['act'] ) && $_REQUEST['act'] == 'update' ) {
		$isShow = htmlspecialchars( $_POST['is_show'], ENT_QUOTES );
		$sort = htmlspecialchars( $_POST['sort'], ENT_QUOTES);
		$uploadFile = upload();
		$slideInfo = array(
			"is_show" => $isShow,
			"sort" => $sort,
		);
		if ( $uploadFile ) { 
			$slideInfo['img'] = $uploadFile;
		}
		if ( $_REQUEST['act'] == 'insert' ) {
			$tipInfo = "添加图片";
			$bRes = $mysql->add( "slide", $slideInfo );
			$act = 'insert';
		}else {
			$id = $_REQUEST['id'];
			$tipInfo = "编辑图片";
			$slideInfo['slide_id'] = $id;
			$bRes = $mysql->update( "slide", $slideInfo, "WHERE slide_id = " . $id );
			$slideInfo = $mysql->getRow( "SELECT * FROM slide WHERE slide_id = " . $_REQUEST['id'] );
			$act = 'update';
		}
		if ( $bRes ) {
			?>
			<script>
			alert( "ok" );
			</script>
			<?Php
		}else {
			?>
			<script>
			alert( "error" );
			</script>
			<?php
		}
	}else if ( isset( $_REQUEST['act'] ) && $_REQUEST['act'] == 'edit' ) {
		if ( !empty( $_REQUEST['id'] ) ) {
			$slideInfo = $mysql->getRow( "SELECT * FROM slide WHERE slide_id = " . $_REQUEST['id'] );
		}
		$tipInfo = "更新图片";
		$act = 'update';
	}
?>

	<div class="container">
		<?php include( "header.php" ); ?>
		<div class="row">
			<form action="" method="post" class="form-horizontal" enctype="multipart/form-data">
				
				<div class="form-group">
					<label for="" class="control-label col-md-2">
						上传图片:
					</label>	
					<div class="col-md-10">
						<input type="file" name="photo" id="photo">
					</div>
				</div>

				<div class="form-group">
					<label for="" class="control-label col-md-2">
						已上传图片:
					</label>		
					<div class="col-md-10">
						<?php
						if ( !empty( $slideInfo['img'] ) ) {
							?>
							<img src="../upload/<?php echo $slideInfo['img']; ?>" alt="">
							<?php
						}
						?>	
					</div>
				</div>

				<div class="form-group">
					<label for="" class="control-label col-md-2">是否显示:</label>
					<div class="col-md-10">
						<label for="" class="radio-inline">
							<input type="radio" name="is_show" id="" value="1" <?php if ( isset( $slideInfo['is_show'] ) && $slideInfo['is_show'] == 1 ) {
									echo "checked";
								}else {
									echo "checked";
								} ?> >是
						</label>
						<label for="" class="radio-inline">
							<input type="radio" name="is_show" id="" value="0" <?php if ( isset( $slideInfo['is_show'] ) && $slideInfo['is_show'] == 0 ) {
									echo "checked";
								} ?>>否
						</label>
					</div>
				</div>
	
				<div class="form-group">
					<label for="sort" class="control-label col-md-2">排序:</label>
					<div class="col-md-4">
						<input type="text" name="sort" id="" class="form-control" value="<?php if ( isset( $slideInfo['sort'] ) ) {
							echo $slideInfo['sort'];
							} ?>">
					</div>
				</div>
				
				<div class="form-group">
					<div class="col-md-offset-2 col-md-10">
						<input class="btn btn-primary" type="submit" value="<?php echo $tipInfo; ?>" name="submit">
					</div>
				</div>	

				<input type="hidden" name="act" value="<?php echo $act; ?>">
				<input type="hidden" name="id" value="<?php if ( !empty( $slideInfo['slide_id']) ){
					echo $slideInfo['slide_id'];
					} ?>">
					
			</form>
		</div>
		
	</div>


</body>
</html>