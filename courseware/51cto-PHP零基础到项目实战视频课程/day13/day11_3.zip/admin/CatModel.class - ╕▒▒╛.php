<?php
	// header( "content-type:text/html;charset=utf-8" );
	// require( "Mysql.class.php" );		
	
	class CatModel extends Mysql {
		public $tbName = "category";

		public function __construct ( $h, $u, $p, $db_name ) {
			parent::__construct( $h, $u, $p, $db_name );
		}

		public function addCategory ( $data ) {
			return $this->add( $this->tbName, $data );
		}

		public function updateCategory ( $data, $condition ) {
			return $this->update( $this->tbName, $data, $condition );
		}

		public function getCatInfo ( $catId ) {
			return $this->getRow( "SELECT * FROM {$this->tbName} WHERE cat_id = " . $catId );
		}

		public function delCat( $catId ) {
			return $this->query( "DELETE FROM {$this->tbName} WHERE cat_id = " . $catId );
		}
	}

	$catModel = new CatModel( "localhost", "root", "root", "php0314" );
	// $catInfo = array(
	// 	"cat_name" => "娱乐",	
	// 	"pid" => 0,
	// );

	// $catInfo = array(
	// 	"cat_name" => "互联网",
	// 	"pid" => 0,
	// );

	// $catModel->addCategory( $catInfo );
	// $catModel->updateCategory( $catInfo, "WHERE cat_id = 1" );
	// print_r( $catModel->getCatInfo( 1 ) );
	// $catModel->delCat( 1 );
	



?>