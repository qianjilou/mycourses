<?php
	require( "init.php" );
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>用户注册&登录</title>
	<link rel="stylesheet" href="../css/bootstrap.css">
</head>
<body>

	<div class="container">
		<div class="row">
			<?php include( "header.php" ); ?>
		</div>
		<?php
		if ( isset( $_POST['reg'] ) ) {
			$userName = htmlspecialchars( $_POST['user_name'], ENT_QUOTES );
			$userPwd = htmlspecialchars( $_POST['user_password'], ENT_QUOTES );
			$data = array(
				"user_name" => $userName,
				"user_password" => $userPwd,
				"reg_time" => date( "Y-m-d H:i:s" ),
			);
			$sql = "SELECT * FROM member WHERE user_name = '$userName'";
			if ( $mysql->getRow( $sql ) ) {
				echo "<script>alert('用户已存在');</script>";
			}else {
				if ( $mysql->add( "member", $data ) ) {
					echo "<script>alert('ok');</script>";
					// header( "Location:user_center.php" );
				}else {
					echo "<script>alert('error');</script>";
				}
			} 
		}else if ( isset( $_POST['login'] ) ) {
			$userName = htmlspecialchars( $_POST['user_name'], ENT_QUOTES );
			$userPwd = htmlspecialchars( $_POST['user_password'], ENT_QUOTES );
			$data = array(
				"user_name" => $userName,
				"user_password" => $userPwd,
			);
			$sql = "SELECT * FROM member WHERE user_name = '$userName' AND user_password = '$userPwd'";
			if ( $userInfo = $mysql->getRow( $sql ) ) {
				$_SESSION['userName'] = $userName;
				$_SESSION['userPwd'] = $userPwd;
				$_SESSION['user_id'] = $userInfo['user_id'];
				echo "<script>location.href='index.php';</script>";
				exit();
			}else {
				echo "<script>alert('用户名或者密码错误');</script>";
			}
		}
		?>
		<div class="row">
			<form action="" class="form-horizontal" method="post">
				<div class="col-md-offset-3 col-md-6">
					<div class="form-group">
						<div class="col-md-12">
							<h3 class="text-center">欢迎登录 ghost 信息管理系统</h3>
						</div>
					</div>
					<div class="form-group">
						<label for="" class="col-md-2 control-label">用户名:</label>
						<div class="col-md-10">
							<input type="text" name="user_name" id="" class="form-control">
						</div>
					</div>
					<div class="form-group">
						<label for="" class="col-md-2 control-label">密码:</label>
						<div class="col-md-10">
							<input type="password" name="user_password" id="" class="form-control">
						</div>
					</div>
					<div class="form-group">
						<div class="col-md-offset-2 col-md-10">
							<input type="submit" class="btn btn-primary" name="reg" value="注册">
							<input type="submit" class="btn btn-primary" name="login" value="登录">
						</div>
					</div>
				</div>
			</form>
		</div>
	</div>

</body>
</html>