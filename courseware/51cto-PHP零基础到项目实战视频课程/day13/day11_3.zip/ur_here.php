<?php
	$catId = !empty( $_REQUEST['id'] ) ? $_REQUEST['id'] : 0;
	$catInfo = $catModel->getCatInfo( $catId );
?>
<ol class="breadcrumb">
	<li><a href="./">首页</a></li>
	<li><a href="cat.php?id=<?php if ( !empty( $catInfo['cat_id'] ) ) {
		echo $catInfo['cat_id'];
		}  ?>"><?php if ( !empty( $catInfo['cat_name'] ) ) {
			echo $catInfo['cat_name'];
			} ?></a></li>	
</ol>