<?php
	session_start();
	if ( isset( $_REQUEST['act'] ) && $_REQUEST['act'] == 'logout' ) {
		unset( $_SESSION['userName'] );
		unset( $_SESSION['userPwd'] );
		header( "Location:index.php" );
		exit();
	}
	if ( empty( $_SESSION['userName'] ) ) {
		header( "Location:index.php" );
		exit();
	}else if ( !empty( $_SESSION['userName'] ) ) {
		$sql = "SELECT * FROM user WHERE user_name = '{$_SESSION['userName']}' AND user_password = '{$_SESSION['userPwd']}'";
		if ( !$mysql->getRow( $sql ) ) {
			header( "Location:index.php" );
			exit();
		}
	}
?>