<?php
	class CatModel extends Mysql {
		public $tbName = "category";
		public $db;
		public function __construct ( &$objDb ) {
			$this->db = $objDb;
		}

		public function addCategory ( $data ) {
			return $this->db->add( $this->tbName, $data );
		}

		public function updateCategory ( $data, $condition ) {
			return $this->db->update( $this->tbName, $data, $condition );
		}

		public function getCatList () {
			return $this->db->getAll( "SELECT * FROM {$this->tbName}" );
		}

		public function getCatInfo ( $catId ) {
			return $this->db->getRow( "SELECT * FROM {$this->tbName} WHERE cat_id = " . $catId );
		}

		public function delCat( $catId ) {
			return $this->db->query( "DELETE FROM {$this->tbName} WHERE cat_id = " . $catId );
		}
	}

	// $catModel = new CatModel( $mysql );


?>